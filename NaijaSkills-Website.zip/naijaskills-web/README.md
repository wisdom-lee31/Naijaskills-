# NaijaSkills Website — React + Firebase

## Quick Start

```bash
cd naijaskills-web
npm install
npm start
```

App runs at http://localhost:3000

## Setup (3 steps)

### 1. Firebase
- Create project at console.firebase.google.com
- Enable: Firestore, Authentication (Email/Password)
- Get web config from Project Settings → Your apps → Web app
- Paste config into `src/services/firebase.js`

### 2. Paystack
- Get public key from dashboard.paystack.com
- Replace `pk_test_YOUR_PUBLIC_KEY_HERE` in `src/utils/constants.js`

### 3. Bank Details (optional)
- Update BANK_NAME, BANK_ACCOUNT_NUM, BANK_ACCOUNT_NAME in `src/utils/constants.js`

## Deploy to Vercel (free)
```bash
npm install -g vercel
vercel
```

## Pages
| Route | Page |
|-------|------|
| / | Home (hero + categories + how it works) |
| /directory | Worker directory (search, filter, Firebase data) |
| /worker/:id | Worker profile + quote request + direct pay |
| /register | Worker registration + ₦1,000 annual fee |
| /quotes | All quote requests (customer or worker view) |
| /quotes/:id | Quote thread (chat + negotiation + Paystack) |
| /admin | Admin panel (approve workers, revenue) |
| ?trusted=NAIJASKILLS_OWNER | Private trusted worker form |

## Private Trusted Worker Link
```
https://yoursite.com?trusted=NAIJASKILLS_OWNER
```
Change NAIJASKILLS_OWNER in src/utils/constants.js before going live.
