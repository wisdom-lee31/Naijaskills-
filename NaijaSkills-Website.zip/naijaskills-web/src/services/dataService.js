import {
  collection, doc, addDoc, updateDoc, deleteDoc,
  getDoc, getDocs, query, where, orderBy, onSnapshot,
  serverTimestamp, arrayUnion
} from "firebase/firestore";
import { db } from "./firebase";

const WORKERS      = "workers";
const QUOTES       = "quotes";
const TRANSACTIONS = "transactions";

// ── Workers ──────────────────────────────────────────────────
export const getApprovedWorkers = () =>
  getDocs(query(collection(db, WORKERS), where("status","==","approved")));

export const getWorkersByCategory = (cat) =>
  getDocs(query(collection(db, WORKERS), where("status","==","approved"), where("category","==",cat)));

export const getWorker = (id) => getDoc(doc(db, WORKERS, id));

export const registerWorker = (data) =>
  addDoc(collection(db, WORKERS), { ...data, status:"pending", verified:false, trusted:false, regPaid:false, rating:0, reviews:0, createdAt: serverTimestamp() });

export const updateWorkerStatus = (id, status, verified) =>
  updateDoc(doc(db, WORKERS, id), { status, verified });

export const markRegPaid = (id, ref, expiry) =>
  updateDoc(doc(db, WORKERS, id), { regPaid:true, regRef:ref, regExpiry:expiry });

export const deleteWorker = (id) => deleteDoc(doc(db, WORKERS, id));

export const getAllWorkers = () =>
  getDocs(query(collection(db, WORKERS), orderBy("createdAt","desc")));

export const addTrustedWorker = (data) =>
  addDoc(collection(db, WORKERS), { ...data, status:"approved", verified:true, trusted:true, regPaid:true, regExpiry:"N/A", rating:5.0, reviews:0, createdAt: serverTimestamp() });

// ── Quotes ───────────────────────────────────────────────────
export const createQuote = (data) =>
  addDoc(collection(db, QUOTES), { ...data, status:"pending", createdAt: serverTimestamp() });

export const getCustomerQuotes = (email) =>
  getDocs(query(collection(db, QUOTES), where("customerEmail","==",email)));

export const getWorkerQuotes = (workerId) =>
  getDocs(query(collection(db, QUOTES), where("workerId","==",workerId)));

export const updateQuote = (id, data) =>
  updateDoc(doc(db, QUOTES, id), data);

export const sendOffer = (id, amount, unit, time) =>
  updateDoc(doc(db, QUOTES, id), {
    workerPrice: amount, status:"countered",
    messages: arrayUnion({ from:"worker", text:`My quote: ₦${Number(amount).toLocaleString()} ${unit}. Please review.`, time, isQuote:true, amount }),
  });

export const acceptQuote = (id, agreedPrice, time) =>
  updateDoc(doc(db, QUOTES, id), {
    agreedPrice, status:"accepted",
    messages: arrayUnion({ from:"system", text:`✅ Accepted at ₦${Number(agreedPrice).toLocaleString()}. Pay to unlock contact.`, time, isSystem:true }),
  });

export const declineQuote = (id, time) =>
  updateDoc(doc(db, QUOTES, id), {
    status:"declined",
    messages: arrayUnion({ from:"system", text:"❌ Quote declined.", time, isSystem:true }),
  });

export const markQuotePaid = (id, ref, phone, time) =>
  updateDoc(doc(db, QUOTES, id), {
    status:"paid", payRef:ref,
    messages: arrayUnion({ from:"system", text:`💳 Payment confirmed! Ref: ${ref} · 📞 ${phone}`, time, isSystem:true }),
  });

export const listenToQuote = (id, callback) =>
  onSnapshot(doc(db, QUOTES, id), callback);

// ── Transactions ─────────────────────────────────────────────
export const logTransaction = (data) =>
  addDoc(collection(db, TRANSACTIONS), { ...data, timestamp: serverTimestamp() });

export const getAllTransactions = () =>
  getDocs(query(collection(db, TRANSACTIONS), orderBy("timestamp","desc")));
