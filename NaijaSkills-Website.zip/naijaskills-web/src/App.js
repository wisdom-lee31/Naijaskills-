import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import "./index.css";
import Navbar      from "./components/Navbar";
import Footer      from "./components/Footer";
import HomePage    from "./pages/HomePage";
import DirectoryPage from "./pages/DirectoryPage";
import WorkerDetailPage from "./pages/WorkerDetailPage";
import RegisterPage from "./pages/RegisterPage";
import QuotesPage  from "./pages/QuotesPage";
import QuoteThreadPage from "./pages/QuoteThreadPage";
import AdminPage   from "./pages/AdminPage";
import TrustedPage from "./pages/TrustedPage";
import NotFound    from "./pages/NotFound";

export default function App() {
  // Detect private trusted link: ?trusted=NAIJASKILLS_OWNER
  const params = new URLSearchParams(window.location.search);
  if (params.get("trusted") === "NAIJASKILLS_OWNER") {
    return (
      <BrowserRouter>
        <Routes>
          <Route path="*" element={<TrustedPage />} />
        </Routes>
      </BrowserRouter>
    );
  }

  return (
    <BrowserRouter>
      <div style={{ display:"flex", flexDirection:"column", minHeight:"100vh" }}>
        <Navbar />
        <main style={{ flex:1 }}>
          <Routes>
            <Route path="/"               element={<HomePage />} />
            <Route path="/directory"      element={<DirectoryPage />} />
            <Route path="/worker/:id"     element={<WorkerDetailPage />} />
            <Route path="/register"       element={<RegisterPage />} />
            <Route path="/quotes"         element={<QuotesPage />} />
            <Route path="/quotes/:id"     element={<QuoteThreadPage />} />
            <Route path="/admin"          element={<AdminPage />} />
            <Route path="*"               element={<NotFound />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  );
}
