import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { G } from "../utils/constants";

const s = {
  header: { background:"linear-gradient(135deg,#005c38,#008751,#00b86a)", position:"sticky", top:0, zIndex:100, boxShadow:"0 2px 16px rgba(0,0,0,.18)" },
  inner:  { maxWidth:1200, margin:"0 auto", display:"flex", alignItems:"center", justifyContent:"space-between", padding:"12px 18px" },
  logo:   { fontFamily:"Syne,sans-serif", fontWeight:800, fontSize:"1.4rem", color:"#fff", textDecoration:"none" },
  logoSpan: { color:"#F5A623" },
  sub:    { fontSize:".6rem", color:"rgba(255,255,255,.65)", letterSpacing:"1.5px", textTransform:"uppercase", marginTop:-2 },
  navLinks: { display:"flex", gap:6, alignItems:"center" },
  hamburger: { background:"none", border:"none", color:"#fff", fontSize:"1.4rem", display:"none" },
};

export default function Navbar() {
  const location = useLocation();
  const [open, setOpen] = useState(false);

  const nb = (path, gold) => ({
    padding:"7px 12px", borderRadius:50,
    border:`1.5px solid ${gold?"#F5A623":"rgba(255,255,255,.4)"}`,
    background: location.pathname===path ? "#fff" : gold ? "#F5A623" : "transparent",
    color: location.pathname===path ? G.greenDark : gold ? G.dark : "#fff",
    fontFamily:"Syne,sans-serif", fontSize:".72rem", fontWeight:600,
    textDecoration:"none", transition:"all .2s", display:"inline-block",
  });

  const links = [
    { to:"/directory", label:"🔍 Directory" },
    { to:"/quotes",    label:"📋 Quotes" },
    { to:"/register",  label:"+ Register", gold:true },
    { to:"/admin",     label:"🛡️ Admin" },
  ];

  return (
    <header style={s.header}>
      <div style={s.inner}>
        <Link to="/" style={{ textDecoration:"none" }}>
          <div style={s.logo}>Naija<span style={s.logoSpan}>Skills</span></div>
          <div style={s.sub}>Nigeria's Skill Directory</div>
        </Link>

        {/* Desktop nav */}
        <nav style={{ display:"flex", gap:6, flexWrap:"wrap", justifyContent:"flex-end" }}
             className="desktop-nav">
          {links.map(l => <Link key={l.to} to={l.to} style={nb(l.to, l.gold)}>{l.label}</Link>)}
        </nav>

        {/* Mobile hamburger */}
        <button style={{ background:"none", border:"none", color:"#fff", fontSize:"1.5rem", cursor:"pointer" }}
                onClick={() => setOpen(!open)}>
          {open ? "✕" : "☰"}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div style={{ background:"rgba(0,70,40,.97)", padding:"12px 18px 18px", display:"flex", flexDirection:"column", gap:8 }}>
          {links.map(l => (
            <Link key={l.to} to={l.to} onClick={() => setOpen(false)}
              style={{ ...nb(l.to, l.gold), textAlign:"center" }}>
              {l.label}
            </Link>
          ))}
        </div>
      )}

      <style>{`
        .desktop-nav { display:none; }
        @media(min-width:640px){ .desktop-nav{display:flex!important;} button[data-ham]{display:none!important;} }
        @media(min-width:640px){ header button:last-child{display:none!important;} .desktop-nav{display:flex!important;} }
      `}</style>
    </header>
  );
}
