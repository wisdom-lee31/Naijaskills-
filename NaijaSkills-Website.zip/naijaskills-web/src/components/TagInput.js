import React, { useState } from "react";
import { G, tagColor, SUGGESTED_TAGS } from "../utils/constants";

const MAX_TAGS = 8;

export default function TagInput({ tags, setTags, category, error }) {
  const [input, setInput] = useState("");

  const addTag = (val) => {
    const v = val.trim().replace(/,/g, "");
    if (!v || tags.includes(v) || tags.length >= MAX_TAGS) return;
    setTags([...tags, v]);
    setInput("");
  };

  const removeTag = (i) => setTags(tags.filter((_, j) => j !== i));

  const handleKey = (e) => {
    if (e.key === "Enter" || e.key === ",") { e.preventDefault(); addTag(input); }
  };

  const suggestions = SUGGESTED_TAGS[category]?.filter(s => !tags.includes(s)).slice(0, 16) || [];

  return (
    <div>
      {/* Selected tags */}
      <div style={{ display:"flex", flexWrap:"wrap", gap:6, border:`1.5px solid ${error ? G.red : "#E5E7EB"}`, borderRadius:10, padding:"8px 10px", background:"#fff", minHeight:48, marginBottom:8 }}>
        {tags.map((t, i) => {
          const c = tagColor(i);
          return (
            <span key={i} style={{ background:c.bg, color:c.color, border:`1px solid ${c.border}`, padding:"4px 10px", borderRadius:50, fontSize:".75rem", fontWeight:600, display:"flex", alignItems:"center", gap:5 }}>
              {t}
              <button type="button" onClick={() => removeTag(i)} style={{ background:"none", border:"none", cursor:"pointer", color:c.color, fontSize:".85rem", padding:0 }}>×</button>
            </span>
          );
        })}
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={handleKey}
          placeholder={tags.length < MAX_TAGS ? "Type tag & press Enter…" : `Max ${MAX_TAGS}`}
          style={{ border:"none", outline:"none", fontSize:".85rem", flex:1, minWidth:100, background:"transparent", color:G.dark }}
          disabled={tags.length >= MAX_TAGS}
        />
      </div>

      {/* Suggestions */}
      {suggestions.length > 0 && (
        <div>
          <div style={{ fontSize:".72rem", color:G.gray, marginBottom:5 }}>💡 Click to add:</div>
          <div style={{ display:"flex", flexWrap:"wrap", gap:5 }}>
            {suggestions.map((s, i) => (
              <button
                key={s}
                type="button"
                onClick={() => addTag(s)}
                disabled={tags.length >= MAX_TAGS}
                style={{ background:G.light, color:G.gray, border:"1px solid #E5E7EB", borderRadius:50, padding:"3px 10px", fontSize:".72rem", fontWeight:500, transition:"all .15s", cursor:"pointer" }}
                onMouseEnter={e => { const c=tagColor(i); e.target.style.background=c.bg; e.target.style.color=c.color; e.target.style.borderColor=c.border; }}
                onMouseLeave={e => { e.target.style.background=G.light; e.target.style.color=G.gray; e.target.style.borderColor="#E5E7EB"; }}>
                + {s}
              </button>
            ))}
          </div>
        </div>
      )}

      <div style={{ fontSize:".7rem", color:G.gray, marginTop:6 }}>
        Up to {MAX_TAGS} tags · {tags.length}/{MAX_TAGS} used
      </div>
      {error && <div style={{ fontSize:".72rem", color:G.red, marginTop:3 }}>{error}</div>}
    </div>
  );
}
