import React from "react";
import { useNavigate } from "react-router-dom";
import { G, tagColor, fmtPrice, stars, AVATAR_BG } from "../utils/constants";

export default function WorkerCard({ worker, index = 0 }) {
  const nav = useNavigate();
  const T   = worker.trusted;

  return (
    <div
      className={`fade-up${T ? " trusted-card" : ""}`}
      style={{
        background: T ? "linear-gradient(135deg,#FFFDF0,#FFF9E0)" : "#fff",
        borderRadius: 16, overflow:"hidden",
        boxShadow: T ? "0 4px 24px rgba(218,165,32,.2)" : "0 4px 24px rgba(0,135,81,.1)",
        border: T ? "2px solid #DAA520" : "none",
        cursor:"pointer", display:"flex", flexDirection:"column",
        transition:"transform .2s, box-shadow .2s",
        animationDelay: `${index * 0.05}s`,
      }}
      onClick={() => nav(`/worker/${worker.id}`)}
      onMouseEnter={e => { e.currentTarget.style.transform="translateY(-4px)"; e.currentTarget.style.boxShadow="0 12px 32px rgba(0,135,81,.16)"; }}
      onMouseLeave={e => { e.currentTarget.style.transform=""; e.currentTarget.style.boxShadow=""; }}
    >
      {/* Avatar */}
      <div style={{ width:"100%", aspectRatio:"1", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"2.5rem", position:"relative", background: T ? "linear-gradient(135deg,#FFF8DC,#FFEAA0)" : AVATAR_BG[worker.category] }}>
        {worker.avatar || "👷"}
        <div style={{ position:"absolute", top:8, right:8, display:"flex", flexDirection:"column", gap:3, alignItems:"flex-end" }}>
          {T
            ? <span className="badge-trusted">👑 Trusted</span>
            : worker.verified && <span className="badge-verified">✓ Verified</span>
          }
        </div>
      </div>

      {/* Body */}
      <div style={{ padding:"10px 10px 12px", flex:1, display:"flex", flexDirection:"column", gap:3 }}>
        <div style={{ fontFamily:"Syne,sans-serif", fontSize:".83rem", fontWeight:700, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{worker.name}</div>
        <div style={{ fontSize:".7rem", color: T ? "#B8860B" : G.green, fontWeight:600 }}>{worker.skill}</div>
        <div style={{ fontSize:".65rem", color:G.gray }}>📍 {worker.city}, {worker.state}</div>
        <div style={{ display:"flex", alignItems:"center", gap:2, marginTop:4, fontSize:".68rem", color:"#F5A623" }}>
          {stars(worker.rating || 0)}
          <span style={{ fontSize:".63rem", color:G.gray, marginLeft:2 }}>({worker.reviews || 0})</span>
        </div>
        <div style={{ fontSize:".67rem", color: T ? "#B8860B" : G.green, fontWeight:600 }}>{fmtPrice(worker)} · 10% fee</div>

        {/* Tags */}
        {worker.tags?.length > 0 && (
          <div style={{ display:"flex", flexWrap:"wrap", gap:3, marginTop:4 }}>
            {worker.tags.slice(0,3).map((t,i) => {
              const c = tagColor(i);
              return <span key={t} style={{ background:c.bg, color:c.color, border:`1px solid ${c.border}`, padding:"2px 7px", borderRadius:50, fontSize:".62rem", fontWeight:600 }}>{t}</span>;
            })}
          </div>
        )}

        {/* Buttons */}
        <div style={{ display:"flex", gap:5, marginTop:10 }}>
          <button
            onClick={e => { e.stopPropagation(); window.location.href = `/quotes/new?worker=${worker.id}`; }}
            style={{ flex:1, background: T ? "linear-gradient(135deg,#DAA520,#B8860B)" : G.green, color:"#fff", border:"none", borderRadius:8, padding:"7px 0", fontSize:".7rem", fontFamily:"Syne,sans-serif", fontWeight:600 }}>
            📋 Get Quote
          </button>
          <button
            onClick={e => { e.stopPropagation(); nav(`/worker/${worker.id}`); }}
            style={{ background:G.light, color:G.dark, border:"none", borderRadius:8, padding:"7px 10px", fontSize:".7rem" }}>
            👁️
          </button>
        </div>
      </div>
    </div>
  );
}
