import React from "react";
import { Link } from "react-router-dom";
import { G, REG_FEE, PLATFORM_FEE_PCT, fmt } from "../utils/constants";

export default function Footer() {
  return (
    <footer style={{ background:G.dark, color:"rgba(255,255,255,.7)", padding:"40px 18px 24px", marginTop:"auto" }}>
      <div style={{ maxWidth:1100, margin:"0 auto" }}>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))", gap:32, marginBottom:32 }}>
          <div>
            <div style={{ fontFamily:"Syne,sans-serif", fontWeight:800, fontSize:"1.3rem", color:"#fff", marginBottom:8 }}>
              Naija<span style={{ color:G.gold }}>Skills</span>
            </div>
            <p style={{ fontSize:".82rem", lineHeight:1.7 }}>
              Connecting Nigerian skilled workers with customers across all 36 states and FCT.
            </p>
          </div>
          <div>
            <div style={{ fontFamily:"Syne,sans-serif", fontWeight:700, color:"#fff", marginBottom:12 }}>Quick Links</div>
            {[["directory","🔍 Browse Workers"],["register","+ Register as Worker"],["quotes","📋 My Quotes"],["admin","🛡️ Admin Panel"]].map(([path,label])=>(
              <Link key={path} to={`/${path}`} style={{ display:"block", color:"rgba(255,255,255,.6)", textDecoration:"none", fontSize:".83rem", marginBottom:6 }}>{label}</Link>
            ))}
          </div>
          <div>
            <div style={{ fontFamily:"Syne,sans-serif", fontWeight:700, color:"#fff", marginBottom:12 }}>Platform Fees</div>
            {[
              ["Annual Reg Fee", `₦${fmt(REG_FEE)}/year`],
              ["Contact Fee",   `${PLATFORM_FEE_PCT}% per job`],
              ["Registration",  "Free to browse"],
            ].map(([k,v])=>(
              <div key={k} style={{ display:"flex", justifyContent:"space-between", fontSize:".8rem", marginBottom:6 }}>
                <span style={{ color:"rgba(255,255,255,.55)" }}>{k}</span>
                <span style={{ color:G.gold, fontWeight:600 }}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div style={{ borderTop:"1px solid rgba(255,255,255,.1)", paddingTop:20, textAlign:"center", fontSize:".75rem", color:"rgba(255,255,255,.4)" }}>
          🇳🇬 NaijaSkills — Made with pride for Nigeria · {new Date().getFullYear()}
        </div>
      </div>
    </footer>
  );
}
