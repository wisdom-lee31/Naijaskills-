import React, { useState } from "react";
import { G, CATEGORIES, STATES, PRICE_UNITS, fmt, REG_FEE, PLATFORM_FEE_PCT, addYear, openPaystack } from "../utils/constants";
import TagInput from "../components/TagInput";
import { registerWorker, markRegPaid, logTransaction } from "../services/dataService";

export default function RegisterPage() {
  const empty = { firstName:"",lastName:"",phone:"",whatsapp:"",email:"",skill:"",category:"",experience:"",priceType:"fixed",priceUnit:"per job",rate:"",rateMin:"",rateMax:"",bio:"",city:"",state:"" };
  const [form,setForm]     = useState(empty);
  const [tags,setTags]     = useState([]);
  const [errs,setErrs]     = useState({});
  const [agreed,setAgreed] = useState(false);
  const [step,setStep]     = useState("form"); // form | pay | done
  const [workerId,setWorkerId] = useState(null);
  const [payMethod,setPayMethod] = useState("paystack");
  const [bankNote,setBankNote]   = useState("");
  const [loading,setLoading]     = useState(false);

  const set = k => e => setForm(f=>({...f,[k]:e.target.value}));
  const baseRate = parseInt(form.priceType==="range"?form.rateMin:form.rate)||0;
  const fee = Math.round(baseRate*PLATFORM_FEE_PCT/100);

  const validate = () => {
    const e={};
    ["firstName","lastName","phone","skill","category","experience","bio","city","state"].forEach(k=>{ if(!form[k].trim()) e[k]="Required"; });
    if(form.priceType==="fixed"&&!form.rate) e.rate="Required";
    if(form.priceType==="range"){ if(!form.rateMin) e.rateMin="Required"; if(!form.rateMax) e.rateMax="Required"; if(parseInt(form.rateMin)>=parseInt(form.rateMax)) e.rateMax="Max must exceed min"; }
    if(tags.length===0) e.tags="Add at least one tag";
    if(!agreed) e.terms="You must accept the terms";
    return e;
  };

  const submit = async () => {
    const e=validate(); if(Object.keys(e).length){setErrs(e);return;}
    setLoading(true);
    const catAv={"Home Services":"🛠️","Construction & Trades":"🏗️","Tech & IT":"💻","Creative & Design":"🎨"};
    try {
      const ref = await registerWorker({
        name:`${form.firstName} ${form.lastName}`,skill:form.skill,category:form.category,
        city:form.city,state:form.state,avatar:catAv[form.category]||"👷",
        phone:form.phone,email:form.email,bio:form.bio,tags,
        rate:parseInt(form.priceType==="range"?form.rateMin:form.rate)||0,
        rateMin:parseInt(form.rateMin)||null,rateMax:parseInt(form.rateMax)||null,
        priceType:form.priceType,priceUnit:form.priceUnit,
      });
      setWorkerId(ref.id);
      setStep("pay");
    } catch(err){ alert("Error: "+err.message); }
    finally{ setLoading(false); }
  };

  const payViaPaystack = () => {
    openPaystack({
      email:form.email||"worker@naijaskills.com",
      amountNaira:REG_FEE,
      metadata:{type:"registration",worker_name:`${form.firstName} ${form.lastName}`},
      onSuccess: async res => {
        await markRegPaid(workerId, res.reference, addYear());
        await logTransaction({ workerName:`${form.firstName} ${form.lastName}`, customerEmail:form.email, jobAmount:REG_FEE, fee:REG_FEE, type:"registration", ref:res.reference });
        setStep("done");
      },
      onClose:()=>{}
    });
  };

  const submitBankProof = async () => {
    if(!bankNote.trim()){alert("Please describe your transfer.");return;}
    await markRegPaid(workerId,"BANK_"+Date.now(),addYear());
    setStep("done");
  };

  const inp = k => ({ className:`form-input${errs[k]?" error":""}` });
  const lbl = (t,req) => <label style={{display:"block",fontSize:".8rem",fontWeight:600,marginBottom:5}}>{t}{req&&<span style={{color:G.red}}> *</span>}</label>;
  const errMsg = k => errs[k]&&<div style={{fontSize:".72rem",color:G.red,marginTop:3}}>{errs[k]}</div>;
  const sec = t => <div className="section-title">{t}</div>;

  if(step==="done") return (
    <div style={{textAlign:"center",padding:"60px 24px"}}>
      <div style={{fontSize:"4rem",marginBottom:12}}>🎉</div>
      <h2 style={{fontFamily:"Syne,sans-serif",fontSize:"1.4rem",fontWeight:800,color:G.green,marginBottom:8}}>Registration Submitted!</h2>
      <p style={{color:G.gray,lineHeight:1.6,marginBottom:20}}>Your profile is pending admin approval. We'll notify you once approved.</p>
      <button onClick={()=>{setStep("form");setForm(empty);setTags([]);setAgreed(false);}} className="btn-primary">Register Another Worker</button>
    </div>
  );

  return (
    <div>
      <div style={{background:"linear-gradient(135deg,#005c38,#008751)",padding:"30px 18px 38px",textAlign:"center"}}>
        <h1 style={{fontFamily:"Syne,sans-serif",fontSize:"1.6rem",fontWeight:800,color:"#fff",marginBottom:6}}>Join NaijaSkills 🇳🇬</h1>
        <p style={{color:"rgba(255,255,255,.8)",fontSize:".88rem"}}>List your skills, get found by customers across Nigeria</p>
      </div>

      {step==="pay" ? (
        <div style={{maxWidth:480,margin:"30px auto",padding:"0 18px 40px"}}>
          <div style={{background:"#fff",borderRadius:16,padding:24,boxShadow:"0 4px 24px rgba(0,0,0,.08)"}}>
            <div style={{textAlign:"center",marginBottom:20}}>
              <div style={{fontSize:"2.5rem",marginBottom:8}}>📋</div>
              <div style={{fontFamily:"Syne,sans-serif",fontSize:"1.1rem",fontWeight:800}}>Annual Registration Fee</div>
              <div style={{fontSize:"3rem",fontFamily:"Syne,sans-serif",fontWeight:800,color:G.green}}>₦{fmt(REG_FEE)}</div>
              <div style={{fontSize:".8rem",color:G.gray}}>Valid for 12 months · Pay once a year</div>
            </div>
            <div style={{display:"flex",gap:8,marginBottom:16}}>
              {[["paystack","💳 Paystack"],["bank","🏦 Bank Transfer"]].map(([v,l])=>(
                <button key={v} onClick={()=>setPayMethod(v)}
                  style={{flex:1,padding:"11px",borderRadius:10,border:`2px solid ${payMethod===v?G.green:"#E5E7EB"}`,background:payMethod===v?"rgba(0,135,81,.06)":"#fff",fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:".82rem",color:payMethod===v?G.green:G.gray}}>
                  {l}
                </button>
              ))}
            </div>
            {payMethod==="paystack" ? (
              <button onClick={payViaPaystack} className="btn-primary" style={{width:"100%"}}>💳 Pay ₦{fmt(REG_FEE)} via Paystack</button>
            ) : (
              <div>
                <div style={{background:G.light,borderRadius:10,padding:14,marginBottom:12}}>
                  {[["Bank","First Bank Nigeria"],["Account No","1234567890"],["Account Name","NaijaSkills Ltd"],["Amount",`₦${fmt(REG_FEE)}`]].map(([k,v])=>(
                    <div key={k} style={{display:"flex",justifyContent:"space-between",fontSize:".82rem",padding:"5px 0",borderBottom:"1px solid #E5E7EB"}}>
                      <span style={{color:G.gray}}>{k}</span><strong>{v}</strong>
                    </div>
                  ))}
                </div>
                <textarea value={bankNote} onChange={e=>setBankNote(e.target.value)} placeholder="Describe your transfer: date, bank, amount, transaction ID…" style={{width:"100%",border:"1.5px solid #E5E7EB",borderRadius:10,padding:"10px 12px",fontSize:".82rem",resize:"vertical",minHeight:90,outline:"none",marginBottom:12}}/>
                <button onClick={submitBankProof} className="btn-primary" style={{width:"100%"}}>Submit Transfer Proof</button>
              </div>
            )}
            <button onClick={()=>setStep("form")} style={{width:"100%",background:"none",border:"none",color:G.gray,fontSize:".8rem",marginTop:10,cursor:"pointer"}}>← Back to form</button>
          </div>
        </div>
      ) : (
        <div style={{maxWidth:600,margin:"0 auto",padding:"0 18px 48px"}}>
          {/* Fee banners */}
          <div style={{display:"flex",flexDirection:"column",gap:10,marginTop:-18,position:"relative",zIndex:2,marginBottom:20}}>
            <div style={{background:"linear-gradient(135deg,#1E40AF,#2563EB)",borderRadius:14,padding:"13px 16px",display:"flex",alignItems:"center",gap:12,boxShadow:"0 4px 20px rgba(37,99,235,.3)"}}>
              <span style={{fontSize:"1.8rem"}}>📋</span>
              <div><div style={{fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:".92rem",color:"#fff"}}>Annual Registration: <span style={{fontSize:"1.2rem"}}>₦{fmt(REG_FEE)}</span></div><div style={{fontSize:".72rem",color:"rgba(255,255,255,.8)"}}>Paid once a year via Paystack or bank transfer</div></div>
            </div>
            <div style={{background:"linear-gradient(135deg,#F5A623,#FFD080)",borderRadius:14,padding:"12px 16px",display:"flex",alignItems:"center",gap:12,boxShadow:"0 4px 20px rgba(245,166,35,.3)"}}>
              <span style={{fontSize:"1.6rem"}}>💰</span>
              <div><div style={{fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:".88rem",color:"#3D2800"}}>+ {PLATFORM_FEE_PCT}% Contact Fee per job</div><div style={{fontSize:".72rem",color:"#6B4500"}}>Charged each time a customer contacts you</div></div>
            </div>
          </div>

          {sec("👤 Personal Information")}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:14}}>
            <div>{lbl("First Name",true)}<input {...inp("firstName")} value={form.firstName} onChange={set("firstName")} placeholder="Chidi"/>{errMsg("firstName")}</div>
            <div>{lbl("Last Name",true)}<input {...inp("lastName")} value={form.lastName} onChange={set("lastName")} placeholder="Okafor"/>{errMsg("lastName")}</div>
          </div>
          <div style={{marginBottom:14}}>{lbl("Phone",true)}<input {...inp("phone")} value={form.phone} onChange={set("phone")} placeholder="08012345678" type="tel"/>{errMsg("phone")}</div>
          <div style={{marginBottom:14}}>{lbl("WhatsApp")}<input className="form-input" value={form.whatsapp} onChange={set("whatsapp")} placeholder="Same as phone?" type="tel"/></div>
          <div style={{marginBottom:14}}>{lbl("Email",true)}<input {...inp("email")} value={form.email} onChange={set("email")} placeholder="yourname@email.com" type="email"/>{errMsg("email")}</div>

          {sec("🛠️ Skill & Work Info")}
          <div style={{marginBottom:14}}>{lbl("Primary Skill",true)}<input {...inp("skill")} value={form.skill} onChange={set("skill")} placeholder="e.g. Plumber, Web Developer"/>{errMsg("skill")}</div>
          <div style={{marginBottom:14}}>{lbl("Category",true)}<select {...inp("category")} value={form.category} onChange={set("category")}><option value="">-- Select --</option>{CATEGORIES.map(c=><option key={c}>{c}</option>)}</select>{errMsg("category")}</div>
          <div style={{marginBottom:14}}>{lbl("Experience",true)}<select {...inp("experience")} value={form.experience} onChange={set("experience")}><option value="">-- Select --</option>{["Less than 1 year","1–2 years","3–5 years","6–10 years","10+ years"].map(x=><option key={x}>{x}</option>)}</select>{errMsg("experience")}</div>

          {/* Pricing */}
          <div style={{marginBottom:14}}>
            {lbl("Pricing Type",true)}
            <div style={{display:"flex",gap:8,marginBottom:10}}>
              {[["fixed","💰 Fixed"],["range","📊 Range"],["negotiable","🤝 Negotiable"]].map(([v,l])=>(
                <button key={v} type="button" onClick={()=>setForm(f=>({...f,priceType:v}))} style={{flex:1,padding:"10px",borderRadius:10,border:`2px solid ${form.priceType===v?G.green:"#E5E7EB"}`,background:form.priceType===v?"rgba(0,135,81,.08)":"#fff",color:form.priceType===v?G.green:G.gray,fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:".78rem"}}>{l}</button>
              ))}
            </div>
            <select className="form-input" value={form.priceUnit} onChange={set("priceUnit")} style={{marginBottom:10}}>{PRICE_UNITS.map(u=><option key={u}>{u}</option>)}</select>
            {form.priceType==="fixed"&&<div><input {...inp("rate")} type="number" value={form.rate} onChange={set("rate")} placeholder="e.g. 5000" min="0"/>{errMsg("rate")}</div>}
            {form.priceType==="range"&&<div style={{display:"grid",gridTemplateColumns:"1fr auto 1fr",gap:8,alignItems:"center"}}><div><input {...inp("rateMin")} type="number" value={form.rateMin} onChange={set("rateMin")} placeholder="Min"/>{errMsg("rateMin")}</div><span style={{textAlign:"center",color:G.gray,fontWeight:700}}>–</span><div><input {...inp("rateMax")} type="number" value={form.rateMax} onChange={set("rateMax")} placeholder="Max"/>{errMsg("rateMax")}</div></div>}
            {form.priceType==="negotiable"&&<div style={{background:"rgba(245,158,11,.1)",border:"1px solid rgba(245,158,11,.3)",borderRadius:10,padding:"10px 13px",fontSize:".82rem",color:"#92400E"}}>🤝 Your profile will show "Negotiable"</div>}
          </div>

          <div style={{marginBottom:14}}>{lbl("Skill Tags",true)}<TagInput tags={tags} setTags={setTags} category={form.category} error={errs.tags}/></div>
          <div style={{marginBottom:14}}>{lbl("Bio",true)}<textarea {...inp("bio")} value={form.bio} onChange={set("bio")} placeholder="Tell customers about your experience…" style={{resize:"vertical",minHeight:90}}/><div style={{fontSize:".72rem",color:G.gray,marginTop:3}}>Minimum 40 characters</div>{errMsg("bio")}</div>

          {sec("📍 Location")}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:20}}>
            <div>{lbl("City",true)}<input {...inp("city")} value={form.city} onChange={set("city")} placeholder="e.g. Lagos"/>{errMsg("city")}</div>
            <div>{lbl("State",true)}<select {...inp("state")} value={form.state} onChange={set("state")}><option value="">-- State --</option>{STATES.map(s=><option key={s}>{s}</option>)}</select>{errMsg("state")}</div>
          </div>

          {/* Fee summary */}
          <div style={{background:"linear-gradient(135deg,#EFF6FF,#DBEAFE)",border:"1.5px solid #93C5FD",borderRadius:14,padding:16,marginBottom:20}}>
            <div style={{fontFamily:"Syne,sans-serif",fontWeight:700,color:"#1E3A5F",marginBottom:10}}>💡 Fee Summary</div>
            {[["Annual Reg Fee",`₦${fmt(REG_FEE)}`],["Payment","Paystack or Bank Transfer"],["After Payment","Admin reviews & approves"],["10% Contact Fee","Per customer contact"]].map(([k,v])=>(
              <div key={k} style={{display:"flex",justifyContent:"space-between",fontSize:".8rem",color:"#1E4080",padding:"3px 0"}}><span style={{color:"#3B82F6"}}>{k}</span><strong>{v}</strong></div>
            ))}
            {baseRate>0&&form.priceType!=="negotiable"&&<div style={{background:"rgba(59,130,246,.1)",borderRadius:8,padding:"7px 10px",marginTop:8,fontSize:".78rem",color:"#1E40AF"}}>📌 Your rate ₦{fmt(baseRate)} → 10% = ₦{fmt(fee)} per contact</div>}
          </div>

          <div style={{display:"flex",alignItems:"flex-start",gap:10,marginBottom:6}}>
            <input type="checkbox" id="terms" checked={agreed} onChange={e=>setAgreed(e.target.checked)} style={{marginTop:2,width:16,height:16,accentColor:G.green,flexShrink:0,cursor:"pointer"}}/>
            <label htmlFor="terms" style={{fontSize:".8rem",color:G.gray,lineHeight:1.5,cursor:"pointer"}}>I agree to the <a href="#" style={{color:G.green}}>Terms & Conditions</a> and understand the <strong>₦{fmt(REG_FEE)} annual fee</strong> and <strong>10% contact fee</strong>.</label>
          </div>
          {errMsg("terms")}

          <button onClick={submit} disabled={loading} className="btn-primary" style={{width:"100%",marginTop:16}}>
            {loading?"Saving…":"🚀 Continue to Payment →"}
          </button>
          <div style={{textAlign:"center",fontSize:".75rem",color:G.gray,marginTop:10}}>You'll pay ₦{fmt(REG_FEE)} on the next step</div>
        </div>
      )}
    </div>
  );
}
