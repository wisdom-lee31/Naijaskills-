import React from "react";
import { useNavigate } from "react-router-dom";
import { G } from "../utils/constants";
export default function NotFound() {
  const nav = useNavigate();
  return (
    <div style={{textAlign:"center",padding:"80px 24px"}}>
      <div style={{fontSize:"4rem",marginBottom:12}}>🇳🇬</div>
      <div style={{fontFamily:"Syne,sans-serif",fontSize:"1.5rem",fontWeight:800,marginBottom:8}}>Page Not Found</div>
      <p style={{color:G.gray,marginBottom:24}}>This page doesn't exist on NaijaSkills.</p>
      <button onClick={()=>nav("/")} className="btn-primary">Go Home</button>
    </div>
  );
}
