import React, { useState, useEffect, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import WorkerCard from "../components/WorkerCard";
import { G, CATEGORIES } from "../utils/constants";
import { getApprovedWorkers } from "../services/dataService";

export default function DirectoryPage() {
  const [searchParams] = useSearchParams();
  const [workers, setWorkers]   = useState([]);
  const [loading, setLoading]   = useState(true);
  const [search,  setSearch]    = useState(searchParams.get("q") || "");
  const [category,setCategory]  = useState(searchParams.get("category") || "all");

  useEffect(() => {
    getApprovedWorkers()
      .then(snap => {
        const data = snap.docs.map(d => ({ id:d.id, ...d.data() }));
        // Sort trusted first
        data.sort((a,b) => Number(b.trusted||false) - Number(a.trusted||false));
        setWorkers(data);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => workers.filter(w => {
    const mc = category === "all" || w.category === category;
    const q  = search.toLowerCase();
    const ms = !q || [w.name,w.skill,w.city,w.state,...(w.tags||[])].some(x => x?.toLowerCase().includes(q));
    return mc && ms;
  }), [workers, search, category]);

  const trusted = filtered.filter(w => w.trusted);
  const regular = filtered.filter(w => !w.trusted);

  const tabS = (v) => ({
    padding:"7px 16px", borderRadius:50, border:`1.5px solid ${category===v?G.green:"#E5E7EB"}`,
    background:category===v?G.green:"#fff", color:category===v?"#fff":G.gray,
    fontSize:".8rem", fontWeight:500, cursor:"pointer", transition:"all .2s", whiteSpace:"nowrap",
  });

  return (
    <div>
      {/* Hero bar */}
      <div style={{ background:"linear-gradient(160deg,#008751,#005c38)", padding:"28px 18px 36px", textAlign:"center" }}>
        <h1 style={{ fontFamily:"Syne,sans-serif", fontSize:"1.7rem", fontWeight:800, color:"#fff", marginBottom:10 }}>
          Find <em style={{fontStyle:"normal",color:"#F5A623"}}>Skilled Workers</em>
        </h1>
        <div style={{ display:"flex", background:"#fff", borderRadius:12, overflow:"hidden", boxShadow:"0 4px 20px rgba(0,0,0,.18)", maxWidth:540, margin:"0 auto" }}>
          <input
            value={search}
            onChange={e=>setSearch(e.target.value)}
            placeholder="Search name, skill, city, or tag…"
            style={{ flex:1, border:"none", outline:"none", padding:"13px 16px", fontSize:".93rem", color:G.dark }}
          />
          {search && <button onClick={()=>setSearch("")} style={{ background:"none", border:"none", padding:"0 12px", color:G.gray, cursor:"pointer" }}>✕</button>}
          <button style={{ background:"#F5A623", border:"none", padding:"0 18px", fontFamily:"Syne,sans-serif", fontWeight:700, fontSize:".85rem", color:G.dark }}>Search</button>
        </div>
      </div>

      {/* Stats */}
      <div className="stat-strip">
        <div style={{textAlign:"center"}}><div className="stat-num">{workers.filter(w=>!w.trusted).length}</div><div className="stat-label">Workers</div></div>
        <div style={{textAlign:"center"}}><div className="stat-num">{workers.filter(w=>w.trusted).length}</div><div className="stat-label">👑 Trusted</div></div>
        <div style={{textAlign:"center"}}><div className="stat-num">10%</div><div className="stat-label">Contact Fee</div></div>
      </div>

      <div className="page-pad">
        {/* Category tabs */}
        <div className="nav-tabs" style={{ marginBottom:20 }}>
          <button style={tabS("all")} onClick={()=>setCategory("all")}>🔍 All</button>
          {CATEGORIES.map(c => (
            <button key={c} style={tabS(c)} onClick={()=>setCategory(c)}>
              {c==="Home Services"?"🏠":c==="Construction & Trades"?"🏗️":c==="Tech & IT"?"💻":"🎨"} {c}
            </button>
          ))}
        </div>

        {loading ? (
          <div style={{ textAlign:"center", padding:"60px 0", color:G.gray }}>
            <div style={{ fontSize:"2rem", marginBottom:8, animation:"shimmer 1s infinite" }}>⏳</div>
            Loading workers…
          </div>
        ) : (
          <>
            {/* Trusted section */}
            {trusted.length > 0 && (
              <div style={{ marginBottom:32 }}>
                <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:12 }}>
                  <div style={{ fontFamily:"Syne,sans-serif", fontSize:"1rem", fontWeight:800 }}>
                    👑 <span style={{color:"#B8860B"}}>Trusted by Owner</span>
                  </div>
                  <div style={{ flex:1, height:1, background:"linear-gradient(90deg,#DAA520,transparent)" }}/>
                </div>
                <div style={{ background:"linear-gradient(135deg,#FFFDF0,#FFF9DC)", border:"1.5px solid #DAA520", borderRadius:12, padding:"10px 14px", marginBottom:14, fontSize:".8rem", color:"#7C5A00" }}>
                  👑 These workers have been <strong>personally vetted and trusted</strong> by the NaijaSkills owner.
                </div>
                <div className="workers-grid">
                  {trusted.map((w,i) => <WorkerCard key={w.id} worker={w} index={i} />)}
                </div>
              </div>
            )}

            {/* Regular workers */}
            {regular.length === 0 && trusted.length === 0 ? (
              <div style={{ textAlign:"center", padding:"60px 20px", color:G.gray }}>
                <div style={{ fontSize:"2.5rem", marginBottom:10 }}>🔍</div>
                <div style={{ fontFamily:"Syne,sans-serif", fontWeight:700, marginBottom:6 }}>No workers found</div>
                <div style={{ fontSize:".85rem" }}>Try a different search or category</div>
              </div>
            ) : (
              <>
                {regular.length > 0 && (
                  <>
                    <div style={{ fontFamily:"Syne,sans-serif", fontWeight:700, fontSize:"1rem", marginBottom:12, color:G.dark }}>
                      {filtered.length} worker{filtered.length !== 1 ? "s" : ""} found
                    </div>
                    <div className="workers-grid">
                      {regular.map((w,i) => <WorkerCard key={w.id} worker={w} index={i} />)}
                    </div>
                  </>
                )}
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}
