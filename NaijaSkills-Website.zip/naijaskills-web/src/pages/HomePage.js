import React from "react";
import { useNavigate } from "react-router-dom";
import { G, CATEGORIES, fmt, REG_FEE, PLATFORM_FEE_PCT } from "../utils/constants";

const CATEGORY_ICONS = {
  "Home Services":"🏠","Construction & Trades":"🏗️","Tech & IT":"💻","Creative & Design":"🎨"
};

export default function HomePage() {
  const nav = useNavigate();
  const [search, setSearch] = React.useState("");

  const handleSearch = (e) => {
    e.preventDefault();
    nav(`/directory?q=${encodeURIComponent(search)}`);
  };

  return (
    <div>
      {/* HERO */}
      <section style={{ background:"linear-gradient(160deg,#008751,#005c38)", padding:"64px 18px 80px", textAlign:"center", position:"relative", overflow:"hidden" }}>
        <div style={{ position:"absolute", width:400, height:400, background:"rgba(255,255,255,.03)", borderRadius:"50%", top:-100, right:-100 }}/>
        <div style={{ position:"absolute", width:280, height:280, background:"rgba(245,166,35,.08)", borderRadius:"50%", bottom:-80, left:-60 }}/>
        <div style={{ position:"relative", zIndex:1, maxWidth:680, margin:"0 auto" }}>
          <div style={{ display:"inline-flex", alignItems:"center", gap:6, background:"rgba(255,255,255,.12)", border:"1px solid rgba(255,255,255,.2)", borderRadius:50, padding:"5px 14px", fontSize:".78rem", color:"rgba(255,255,255,.9)", marginBottom:20 }}>
            🇳🇬 Nigeria's #1 Skilled Worker Directory
          </div>
          <h1 style={{ fontFamily:"Syne,sans-serif", fontSize:"clamp(2rem,5vw,3.2rem)", fontWeight:800, color:"#fff", lineHeight:1.1, marginBottom:14 }}>
            Find <em style={{ fontStyle:"normal", color:"#F5A623" }}>Skilled Workers</em><br/>Across Nigeria
          </h1>
          <p style={{ color:"rgba(255,255,255,.8)", fontSize:"1.05rem", lineHeight:1.7, marginBottom:32 }}>
            Connect with trusted professionals in all 36 states. Get quotes before paying — only a <strong style={{color:"#F5A623"}}>10% fee</strong> per job contact.
          </p>

          {/* Search */}
          <form onSubmit={handleSearch} style={{ display:"flex", background:"#fff", borderRadius:14, overflow:"hidden", boxShadow:"0 8px 32px rgba(0,0,0,.2)", maxWidth:560, margin:"0 auto 32px" }}>
            <input
              value={search}
              onChange={e=>setSearch(e.target.value)}
              placeholder="Search plumber, web developer, tailor, Lagos…"
              style={{ flex:1, border:"none", outline:"none", padding:"16px 18px", fontSize:".95rem", color:G.dark }}
            />
            <button type="submit" style={{ background:"#F5A623", border:"none", padding:"0 22px", fontFamily:"Syne,sans-serif", fontWeight:700, fontSize:".9rem", color:G.dark, cursor:"pointer" }}>
              Search
            </button>
          </form>

          {/* Stats */}
          <div style={{ display:"flex", justifyContent:"center", gap:32, flexWrap:"wrap" }}>
            {[["1,200+","Workers"],["36","States"],["4","Categories"]].map(([n,l])=>(
              <div key={l} style={{ textAlign:"center" }}>
                <div style={{ fontFamily:"Syne,sans-serif", fontSize:"1.6rem", fontWeight:800, color:"#F5A623" }}>{n}</div>
                <div style={{ fontSize:".75rem", color:"rgba(255,255,255,.7)", textTransform:"uppercase", letterSpacing:"0.8px" }}>{l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CATEGORIES */}
      <section style={{ padding:"48px 18px", maxWidth:1100, margin:"0 auto" }}>
        <div style={{ textAlign:"center", marginBottom:32 }}>
          <h2 style={{ fontFamily:"Syne,sans-serif", fontSize:"1.8rem", fontWeight:800, marginBottom:8 }}>Browse by <span style={{color:G.green}}>Category</span></h2>
          <p style={{ color:G.gray, fontSize:".95rem" }}>Find the right skill for your job</p>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))", gap:16 }}>
          {CATEGORIES.map(cat => (
            <button key={cat} onClick={() => nav(`/directory?category=${encodeURIComponent(cat)}`)}
              style={{ background:"#fff", border:"1.5px solid #E5E7EB", borderRadius:16, padding:"24px 20px", textAlign:"left", cursor:"pointer", transition:"all .2s", boxShadow:"0 2px 12px rgba(0,0,0,.06)" }}
              onMouseEnter={e=>{e.currentTarget.style.borderColor=G.green;e.currentTarget.style.transform="translateY(-3px)";}}
              onMouseLeave={e=>{e.currentTarget.style.borderColor="#E5E7EB";e.currentTarget.style.transform="";}}>
              <div style={{ fontSize:"2.2rem", marginBottom:10 }}>{CATEGORY_ICONS[cat]}</div>
              <div style={{ fontFamily:"Syne,sans-serif", fontWeight:700, fontSize:"1rem", marginBottom:4 }}>{cat}</div>
              <div style={{ fontSize:".78rem", color:G.gray }}>Browse workers →</div>
            </button>
          ))}
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section style={{ background:"#fff", padding:"48px 18px" }}>
        <div style={{ maxWidth:1000, margin:"0 auto", textAlign:"center" }}>
          <h2 style={{ fontFamily:"Syne,sans-serif", fontSize:"1.8rem", fontWeight:800, marginBottom:8 }}>How It <span style={{color:G.green}}>Works</span></h2>
          <p style={{ color:G.gray, marginBottom:36 }}>Simple, safe, transparent</p>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))", gap:24 }}>
            {[
              ["1","🔍","Browse Workers","Search by skill, city, or category across all of Nigeria."],
              ["2","📋","Request a Quote","Describe your job. The worker replies with a price — no payment yet."],
              ["3","🤝","Agree on Price","Negotiate freely. Accept, decline, or counter-offer until you're happy."],
              ["4","💳","Pay & Connect","Pay the 10% platform fee and get the worker's direct contact instantly."],
            ].map(([num,icon,title,desc])=>(
              <div key={num} style={{ padding:"24px 18px", borderRadius:16, background:G.cream, border:"1px solid #E5E7EB" }}>
                <div style={{ width:36, height:36, background:G.green, color:"#fff", borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"Syne,sans-serif", fontWeight:800, fontSize:".9rem", margin:"0 auto 12px" }}>{num}</div>
                <div style={{ fontSize:"1.8rem", marginBottom:8 }}>{icon}</div>
                <div style={{ fontFamily:"Syne,sans-serif", fontWeight:700, marginBottom:6 }}>{title}</div>
                <div style={{ fontSize:".82rem", color:G.gray, lineHeight:1.6 }}>{desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FOR WORKERS CTA */}
      <section style={{ padding:"48px 18px" }}>
        <div style={{ maxWidth:800, margin:"0 auto" }}>
          <div style={{ background:"linear-gradient(135deg,#005c38,#008751)", borderRadius:20, padding:"40px 32px", color:"#fff", display:"flex", flexWrap:"wrap", gap:24, alignItems:"center", justifyContent:"space-between" }}>
            <div>
              <h2 style={{ fontFamily:"Syne,sans-serif", fontSize:"1.6rem", fontWeight:800, marginBottom:8 }}>Are you a Skilled Worker?</h2>
              <p style={{ color:"rgba(255,255,255,.8)", fontSize:".95rem", lineHeight:1.6 }}>
                Register for just <strong style={{color:"#F5A623"}}>₦{fmt(REG_FEE)}/year</strong> and reach customers all over Nigeria.<br/>
                Pay only <strong style={{color:"#F5A623"}}>{PLATFORM_FEE_PCT}%</strong> per contact — no job, no fee!
              </p>
            </div>
            <button onClick={() => nav("/register")} style={{ background:"#F5A623", border:"none", borderRadius:12, padding:"14px 28px", fontFamily:"Syne,sans-serif", fontWeight:800, fontSize:"1rem", color:G.dark, cursor:"pointer", whiteSpace:"nowrap", flexShrink:0 }}>
              Register Now →
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
