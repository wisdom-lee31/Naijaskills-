import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { G, CATEGORIES, STATES } from "../utils/constants";
import TagInput from "../components/TagInput";
import { addTrustedWorker } from "../services/dataService";

export default function TrustedPage() {
  const nav = useNavigate();
  const [done, setDone] = useState(false);
  const [f, setF] = useState({name:"",phone:"",skill:"",cat:"",city:"",state:"",priceType:"fixed",priceUnit:"per job",rate:"",bio:"",avatar:""});
  const [tags, setTags] = useState([]);
  const [loading, setLoading] = useState(false);
  const set = k => e => setF(p=>({...p,[k]:e.target.value}));
  const submit = async () => {
    if(!f.name||!f.phone||!f.skill||!f.cat||!f.bio){alert("Fill required fields");return;}
    setLoading(true);
    const catAv={"Home Services":"🛠️","Construction & Trades":"🏗️","Tech & IT":"💻","Creative & Design":"🎨"};
    await addTrustedWorker({name:f.name,phone:f.phone,skill:f.skill,category:f.cat,city:f.city,state:f.state,avatar:f.avatar||catAv[f.cat]||"👷",bio:f.bio,tags,rate:parseInt(f.rate)||0,priceType:f.priceType,priceUnit:f.priceUnit});
    setLoading(false); setDone(true);
  };
  const inp=k=>({className:"form-input",value:f[k],onChange:set(k)});
  const lbl=(t,r)=><label style={{display:"block",fontSize:".8rem",fontWeight:600,marginBottom:5}}>{t}{r&&<span style={{color:G.red}}> *</span>}</label>;
  if(done) return (
    <div style={{textAlign:"center",padding:"60px 24px"}}>
      <div style={{fontSize:"4rem",marginBottom:12}}>👑</div>
      <div style={{fontFamily:"Syne,sans-serif",fontSize:"1.3rem",fontWeight:800,color:"#B8860B",marginBottom:8}}>Trusted Worker Added!</div>
      <p style={{color:G.gray,marginBottom:20}}>They're live in the directory with the Trusted by Owner badge.</p>
      <div style={{display:"flex",gap:10,justifyContent:"center"}}>
        <button onClick={()=>setDone(false)} className="btn-gold">Add Another</button>
        <button onClick={()=>nav("/directory")} className="btn-primary">View Directory</button>
      </div>
    </div>
  );
  return (
    <div style={{maxWidth:540,margin:"0 auto",padding:"28px 18px 48px"}}>
      <div style={{textAlign:"center",marginBottom:24}}>
        <div style={{fontSize:"2.4rem",marginBottom:8}}>👑</div>
        <div style={{fontFamily:"Syne,sans-serif",fontSize:"1.4rem",fontWeight:800,color:"#B8860B"}}>Add Trusted Worker</div>
        <div style={{fontSize:".85rem",color:"#7C5A00",marginTop:4}}>Private owner access · No registration fee required</div>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:14}}><div>{lbl("Full Name",true)}<input {...inp("name")} placeholder="e.g. Chidi Okeke"/></div><div>{lbl("Phone",true)}<input {...inp("phone")} placeholder="08012345678" type="tel"/></div></div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:14}}><div>{lbl("Skill",true)}<input {...inp("skill")} placeholder="e.g. Plumber"/></div><div>{lbl("Category",true)}<select {...inp("cat")}><option value="">--</option>{CATEGORIES.map(c=><option key={c} value={c}>{c}</option>)}</select></div></div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:14}}><div>{lbl("City")}<input {...inp("city")} placeholder="e.g. Lagos"/></div><div>{lbl("State")}<select {...inp("state")}><option value="">--</option>{STATES.map(s=><option key={s}>{s}</option>)}</select></div></div>
      <div style={{marginBottom:14}}>{lbl("Rate (₦)")}<input {...inp("rate")} type="number" min="0" placeholder="5000"/></div>
      <div style={{marginBottom:14}}>{lbl("Skill Tags",true)}<TagInput tags={tags} setTags={setTags} category={f.cat}/></div>
      <div style={{marginBottom:20}}>{lbl("Bio",true)}<textarea {...inp("bio")} placeholder="Why do you trust this worker?" style={{resize:"vertical",minHeight:90}}/></div>
      <button onClick={submit} disabled={loading} className="btn-gold" style={{width:"100%",fontSize:"1rem",padding:15}}>{loading?"Saving…":"👑 Add as Trusted Worker"}</button>
    </div>
  );
}
