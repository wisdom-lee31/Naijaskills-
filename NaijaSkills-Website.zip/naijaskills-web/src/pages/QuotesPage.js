import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { G, QUOTE_STATUS_LABELS, fmt } from "../utils/constants";
import { getCustomerQuotes, getWorkerQuotes } from "../services/dataService";

export default function QuotesPage() {
  const nav = useNavigate();
  const [quotes, setQuotes] = useState([]);
  const [view, setView]     = useState("customer");
  const [email, setEmail]   = useState(localStorage.getItem("ns_email")||"");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);

  const load = async () => {
    if (!email.trim()) return;
    setLoading(true);
    localStorage.setItem("ns_email", email);
    try {
      const snap = view==="customer" ? await getCustomerQuotes(email) : await getWorkerQuotes(email);
      setQuotes(snap.docs.map(d=>({id:d.id,...d.data()})));
    } catch(e){ console.error(e); }
    finally { setLoading(false); }
  };

  useEffect(()=>{ if(email) load(); }, [view]);

  const filtered = quotes.filter(q => !search || q.jobTitle?.toLowerCase().includes(search.toLowerCase()) || q.workerName?.toLowerCase().includes(search.toLowerCase()));

  const sc = { pending:{bg:"rgba(245,158,11,.1)",color:"#92400E"}, countered:{bg:"rgba(37,99,235,.1)",color:G.blue}, accepted:{bg:"rgba(0,135,81,.1)",color:G.green}, declined:{bg:"rgba(220,38,38,.1)",color:G.red}, paid:{bg:"rgba(0,135,81,.15)",color:G.greenDark} };

  const tabS = v => ({ padding:"8px 16px", borderRadius:50, fontSize:".8rem", fontWeight:600, border:`1.5px solid ${view===v?G.green:"#E5E7EB"}`, background:view===v?G.green:"#fff", color:view===v?"#fff":G.gray, cursor:"pointer", fontFamily:"Syne,sans-serif" });

  return (
    <div className="page-pad">
      <div style={{fontFamily:"Syne,sans-serif",fontSize:"1.3rem",fontWeight:800,marginBottom:4}}>📋 Quotations</div>
      <div style={{fontSize:".83rem",color:G.gray,marginBottom:20}}>Track all your job quote requests and negotiations</div>

      {/* Stats */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,marginBottom:20}}>
        {[[quotes.length,"Total","📋"],[quotes.filter(q=>q.status==="pending").length,"Pending","⏳"],[quotes.filter(q=>["countered","accepted"].includes(q.status)).length,"Active","🔄"],[quotes.filter(q=>q.status==="paid").length,"Paid","💳"]].map(([n,l,i])=>(
          <div key={l} style={{background:"#fff",borderRadius:14,padding:"12px 8px",textAlign:"center",boxShadow:"0 2px 12px rgba(0,0,0,.06)"}}>
            <div style={{fontSize:"1rem",marginBottom:3}}>{i}</div>
            <div style={{fontFamily:"Syne,sans-serif",fontSize:".95rem",fontWeight:800,color:G.green}}>{n}</div>
            <div style={{fontSize:".6rem",color:G.gray,textTransform:"uppercase",letterSpacing:".6px"}}>{l}</div>
          </div>
        ))}
      </div>

      {/* Email input */}
      <div style={{background:"#fff",borderRadius:14,padding:16,marginBottom:16,boxShadow:"0 2px 12px rgba(0,0,0,.06)"}}>
        <div style={{fontSize:".82rem",fontWeight:600,marginBottom:8}}>Enter your email to view your quotes:</div>
        <div style={{display:"flex",gap:8}}>
          <input className="form-input" type="email" value={email} onChange={e=>setEmail(e.target.value)} onKeyDown={e=>e.key==="Enter"&&load()} placeholder="yourname@email.com" style={{flex:1}}/>
          <button onClick={load} className="btn-primary" style={{padding:"10px 18px",fontSize:".85rem"}}>Load</button>
        </div>
      </div>

      <div style={{display:"flex",gap:8,marginBottom:14}}>
        <button style={tabS("customer")} onClick={()=>setView("customer")}>👤 As Customer</button>
        <button style={tabS("worker")}   onClick={()=>setView("worker")}>🔧 As Worker</button>
      </div>

      <input className="form-input" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search quotes…" style={{marginBottom:16}}/>

      {loading && <div style={{textAlign:"center",padding:"40px",color:G.gray}}>Loading…</div>}
      {!loading && filtered.length===0 && <div style={{textAlign:"center",padding:"40px",color:G.gray}}><div style={{fontSize:"2rem",marginBottom:8}}>📋</div>No quotes found.</div>}

      {filtered.map(q => {
        const s = sc[q.status]||sc.pending;
        const last = q.messages?.[q.messages.length-1];
        return (
          <div key={q.id} onClick={()=>nav(`/quotes/${q.id}?worker=${view==="worker"}`)} style={{background:"#fff",borderRadius:14,padding:"14px 16px",marginBottom:10,boxShadow:"0 2px 12px rgba(0,0,0,.06)",cursor:"pointer",borderLeft:`4px solid ${s.color}`,transition:"box-shadow .2s"}}
            onMouseEnter={e=>e.currentTarget.style.boxShadow="0 6px 24px rgba(0,135,81,.15)"}
            onMouseLeave={e=>e.currentTarget.style.boxShadow="0 2px 12px rgba(0,0,0,.06)"}>
            <div style={{display:"flex",justifyContent:"space-between",gap:8}}>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:".9rem",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{q.jobTitle}</div>
                <div style={{fontSize:".75rem",color:G.gray,marginTop:2}}>{view==="customer"?`Worker: ${q.workerName}`:`Customer: ${q.customerName}`} · {q.createdAt?.toDate?.()?.toLocaleDateString()||q.createdAt||""}</div>
                {last&&<div style={{fontSize:".75rem",color:G.gray,marginTop:3,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis",fontStyle:"italic"}}>"{last.text?.substring(0,60)}{last.text?.length>60?"…":""}"</div>}
              </div>
              <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:4,flexShrink:0}}>
                <span style={{background:s.bg,color:s.color,padding:"2px 9px",borderRadius:50,fontSize:".65rem",fontWeight:700,fontFamily:"Syne,sans-serif"}}>{QUOTE_STATUS_LABELS[q.status]}</span>
                {q.agreedPrice>0&&<span style={{fontSize:".72rem",color:G.green,fontWeight:700}}>₦{fmt(q.agreedPrice)}</span>}
                <span style={{fontSize:".65rem",color:G.gray}}>{q.messages?.length||0} msg{q.messages?.length!==1?"s":""}</span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
