import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { G, fmtPrice, stars, tagColor, AVATAR_BG, fmt, PLATFORM_FEE_PCT, openPaystack, now } from "../utils/constants";
import { getWorker, createQuote, logTransaction } from "../services/dataService";

export default function WorkerDetailPage() {
  const { id } = useParams();
  const nav = useNavigate();
  const [worker, setWorker] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showQuote, setShowQuote] = useState(false);
  const [showPay, setShowPay] = useState(false);
  const [jobAmt, setJobAmt] = useState("");
  const [email, setEmail] = useState("");
  const [payLoading, setPayLoading] = useState(false);

  useEffect(() => {
    getWorker(id).then(doc => {
      if (doc.exists()) setWorker({ id:doc.id, ...doc.data() });
    }).finally(() => setLoading(false));
  }, [id]);

  const fee = Math.round((parseInt(jobAmt)||0) * PLATFORM_FEE_PCT / 100);
  const T = worker?.trusted;

  const handlePay = () => {
    if (!email || !jobAmt || parseInt(jobAmt) < 100) { alert("Enter email and job amount (min ₦100)"); return; }
    setPayLoading(true);
    openPaystack({
      email, amountNaira: fee,
      metadata:{ worker_name:worker.name, job_amount:parseInt(jobAmt), platform_fee:fee },
      onSuccess: async res => {
        await logTransaction({ workerName:worker.name, customerEmail:email, jobAmount:parseInt(jobAmt), fee, type:"contact", ref:res.reference });
        alert(`✅ Payment successful! Worker contact: ${worker.phone}\nRef: ${res.reference}`);
        setShowPay(false); setPayLoading(false);
      },
      onClose:() => setPayLoading(false),
    });
  };

  const handleQuoteSubmit = async (quoteData) => {
    await createQuote({ ...quoteData, workerId:id, workerName:worker.name, workerSkill:worker.skill, workerPhone:worker.phone });
    setShowQuote(false);
    nav("/quotes");
  };

  if (loading) return <div style={{textAlign:"center",padding:"80px",color:G.gray}}>Loading…</div>;
  if (!worker) return <div style={{textAlign:"center",padding:"80px",color:G.red}}>Worker not found.</div>;

  return (
    <div style={{maxWidth:700,margin:"0 auto",padding:"24px 18px 60px"}}>
      <button onClick={()=>nav(-1)} style={{background:"none",border:"none",color:G.gray,cursor:"pointer",marginBottom:16,display:"flex",alignItems:"center",gap:6,fontSize:".85rem"}}>← Back</button>

      {/* Profile card */}
      <div style={{background:T?"linear-gradient(135deg,#FFFDF0,#FFF9E0)":"#fff",borderRadius:20,padding:28,boxShadow:T?"0 4px 24px rgba(218,165,32,.2)":"0 4px 24px rgba(0,0,0,.08)",border:T?"2px solid #DAA520":"none",marginBottom:20}}>
        {T && <div style={{background:"linear-gradient(135deg,#DAA520,#FFD700)",borderRadius:10,padding:"8px 14px",marginBottom:16,textAlign:"center"}}><div style={{fontFamily:"Syne,sans-serif",fontWeight:800,color:"#3D2800"}}>👑 Personally Trusted by NaijaSkills Owner</div></div>}
        <div style={{display:"flex",gap:20,flexWrap:"wrap",alignItems:"flex-start"}}>
          <div style={{width:80,height:80,borderRadius:16,background:T?"linear-gradient(135deg,#FFF8DC,#FFEAA0)":AVATAR_BG[worker.category],display:"flex",alignItems:"center",justifyContent:"center",fontSize:"2.5rem",flexShrink:0}}>{worker.avatar||"👷"}</div>
          <div style={{flex:1,minWidth:200}}>
            <div style={{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap",marginBottom:6}}>
              <h1 style={{fontFamily:"Syne,sans-serif",fontSize:"1.4rem",fontWeight:800}}>{worker.name}</h1>
              {T ? <span className="badge-trusted">👑 Trusted</span> : worker.verified && <span className="badge-verified">✓ Verified</span>}
            </div>
            <div style={{color:T?"#B8860B":G.green,fontWeight:600,marginBottom:4}}>{worker.skill} · {worker.category}</div>
            <div style={{color:G.gray,fontSize:".85rem",marginBottom:6}}>📍 {worker.city}, {worker.state}</div>
            <div style={{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}}>
              <span style={{background:"rgba(0,135,81,.1)",color:G.green,padding:"4px 14px",borderRadius:50,fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:".85rem"}}>💰 {fmtPrice(worker)}</span>
              <span style={{fontSize:".8rem",color:G.gray}}>⭐ {worker.rating||0} ({worker.reviews||0} reviews)</span>
            </div>
          </div>
        </div>
        <div style={{background:G.light,borderRadius:12,padding:"12px 14px",margin:"16px 0",fontSize:".88rem",lineHeight:1.7,color:G.dark}}>{worker.bio}</div>
        {worker.tags?.length>0 && <div style={{display:"flex",flexWrap:"wrap",gap:6,marginBottom:16}}>{worker.tags.map((t,i)=>{const c=tagColor(i);return<span key={t} style={{background:c.bg,color:c.color,border:`1px solid ${c.border}`,padding:"4px 12px",borderRadius:50,fontSize:".75rem",fontWeight:600}}>{t}</span>;})}</div>}

        {/* Fee notice */}
        <div style={{background:"linear-gradient(135deg,#FFF8E1,#FFFDE7)",border:"1.5px solid #F5A623",borderRadius:10,padding:"10px 14px",marginBottom:16,fontSize:".82rem",color:"#7C5A00"}}>
          <strong style={{fontFamily:"Syne,sans-serif",display:"block",marginBottom:2,color:"#5C4000"}}>💰 Contact Fee Notice</strong>
          A <strong>10% platform fee</strong> is charged on the agreed job amount.
        </div>

        {/* Action buttons */}
        <div style={{display:"flex",gap:10,flexWrap:"wrap"}}>
          <button onClick={()=>setShowQuote(true)} className="btn-primary" style={{flex:1,minWidth:160}}>📋 Request a Quote (Free)</button>
          <button onClick={()=>setShowPay(true)} style={{flex:1,minWidth:120,background:G.light,color:G.dark,border:"1.5px solid #E5E7EB",borderRadius:12,padding:12,fontFamily:"Syne,sans-serif",fontWeight:600,fontSize:".85rem"}}>📞 Direct Contact</button>
        </div>
      </div>

      {/* Quote Request Form */}
      {showQuote && <QuoteForm worker={worker} onSubmit={handleQuoteSubmit} onClose={()=>setShowQuote(false)}/>}

      {/* Direct Pay Modal */}
      {showPay && (
        <div className="modal-overlay center" onClick={e=>e.target.className.includes("modal-overlay")&&setShowPay(false)}>
          <div className="modal-box pop-in" style={{padding:24}}>
            <div style={{fontSize:"2.4rem",textAlign:"center",marginBottom:8}}>💳</div>
            <div style={{fontFamily:"Syne,sans-serif",fontSize:"1.1rem",fontWeight:800,textAlign:"center",marginBottom:16}}>Direct Contact Payment</div>
            <div style={{marginBottom:12}}><label style={{fontSize:".8rem",fontWeight:600}}>📧 Your Email *</label><input className="form-input" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="yourname@email.com" style={{marginTop:4}}/></div>
            <div style={{marginBottom:12}}><label style={{fontSize:".8rem",fontWeight:600}}>💼 Job Amount (₦) *</label><input className="form-input" type="number" value={jobAmt} onChange={e=>setJobAmt(e.target.value)} placeholder="e.g. 10000" min="0" style={{marginTop:4}}/></div>
            <div style={{background:"linear-gradient(135deg,#008751,#00b86a)",borderRadius:10,padding:"10px 14px",marginBottom:14,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div><div style={{fontSize:".78rem",color:"rgba(255,255,255,.85)"}}>10% Fee</div><div style={{fontFamily:"Syne,sans-serif",fontSize:"1.2rem",fontWeight:800,color:"#fff"}}>₦{fmt(fee)}</div></div>
              <div style={{textAlign:"right"}}><div style={{fontSize:".78rem",color:"rgba(255,255,255,.75)"}}>Job Amount</div><div style={{fontSize:".95rem",fontWeight:700,color:"rgba(255,255,255,.9)"}}>₦{fmt(parseInt(jobAmt)||0)}</div></div>
            </div>
            <button onClick={handlePay} disabled={payLoading} className="btn-primary" style={{width:"100%",marginBottom:8}}>{payLoading?"Opening Paystack…":"✅ Pay & Get Contact"}</button>
            <button onClick={()=>setShowPay(false)} style={{width:"100%",background:"none",border:"none",color:G.gray,fontSize:".8rem",cursor:"pointer"}}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
}

function QuoteForm({ worker, onSubmit, onClose }) {
  const [f,setF] = useState({customerName:"",customerEmail:"",customerPhone:"",jobTitle:"",jobDesc:"",jobDate:"",jobLocation:""});
  const [loading,setLoading] = useState(false);
  const set = k => e => setF(p=>({...p,[k]:e.target.value}));
  const submit = async () => {
    if(!f.customerName||!f.customerEmail||!f.customerPhone||!f.jobTitle||!f.jobDesc){alert("Fill required fields");return;}
    setLoading(true);
    await onSubmit({ ...f, messages:[{from:"customer",text:f.jobDesc,time:now()}] });
    setLoading(false);
  };
  const lbl=(t,req)=><label style={{display:"block",fontSize:".78rem",fontWeight:600,marginBottom:4}}>{t}{req&&<span style={{color:G.red}}> *</span>}</label>;
  return (
    <div className="modal-overlay" onClick={e=>e.target.className.includes("modal-overlay")&&onClose()}>
      <div className="modal-sheet slide-up" style={{padding:"22px 20px 36px"}}>
        <button className="modal-close-btn" onClick={onClose}>✕</button>
        <div className="modal-handle"/>
        <div style={{fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"1rem",marginBottom:4}}>📋 Request a Quote from {worker.name}</div>
        <div style={{fontSize:".8rem",color:G.gray,marginBottom:16}}>Describe your job. The worker replies with a price — no payment yet.</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:10}}>
          <div>{lbl("Name",true)}<input className="form-input" value={f.customerName} onChange={set("customerName")} placeholder="Your name"/></div>
          <div>{lbl("Phone",true)}<input className="form-input" value={f.customerPhone} onChange={set("customerPhone")} placeholder="08012345678" type="tel"/></div>
        </div>
        <div style={{marginBottom:10}}>{lbl("Email",true)}<input className="form-input" value={f.customerEmail} onChange={set("customerEmail")} placeholder="yourname@email.com" type="email"/></div>
        <div style={{marginBottom:10}}>{lbl("Job Title",true)}<input className="form-input" value={f.jobTitle} onChange={set("jobTitle")} placeholder="e.g. Deep clean 3-bedroom flat"/></div>
        <div style={{marginBottom:10}}>{lbl("Job Description",true)}<textarea className="form-input" value={f.jobDesc} onChange={set("jobDesc")} placeholder="Describe the job in detail…" style={{resize:"vertical",minHeight:80}}/></div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:16}}>
          <div>{lbl("Date")}<input className="form-input" type="date" value={f.jobDate} onChange={set("jobDate")}/></div>
          <div>{lbl("Location")}<input className="form-input" value={f.jobLocation} onChange={set("jobLocation")} placeholder="e.g. Lekki, Lagos"/></div>
        </div>
        <div style={{background:"rgba(245,158,11,.08)",border:"1px solid rgba(245,158,11,.25)",borderRadius:10,padding:"10px 13px",marginBottom:14,fontSize:".78rem",color:"#92400E"}}>
          💡 <strong>No payment yet.</strong> The worker will send a quote first.
        </div>
        <button onClick={submit} disabled={loading} className="btn-primary" style={{width:"100%"}}>{loading?"Sending…":"📤 Send Quote Request"}</button>
      </div>
    </div>
  );
}
