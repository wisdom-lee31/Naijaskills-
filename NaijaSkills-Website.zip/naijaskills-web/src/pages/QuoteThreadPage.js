import React, { useState, useEffect, useRef } from "react";
import { useParams, useSearchParams, useNavigate } from "react-router-dom";
import { G, fmt, PLATFORM_FEE_PCT, now, openPaystack } from "../utils/constants";
import { listenToQuote, updateQuote, sendOffer, acceptQuote, declineQuote, markQuotePaid, logTransaction } from "../services/dataService";

export default function QuoteThreadPage() {
  const { id } = useParams();
  const [sp]   = useSearchParams();
  const nav    = useNavigate();
  const isWorker = sp.get("worker") === "true";

  const [quote, setQuote]     = useState(null);
  const [msg, setMsg]         = useState("");
  const [offerAmt, setOfferAmt] = useState("");
  const [showOffer, setShowOffer] = useState(false);
  const [paying, setPaying]   = useState(false);
  const messagesEnd = useRef(null);

  useEffect(() => {
    const unsub = listenToQuote(id, snap => {
      if (snap.exists()) setQuote({ id:snap.id, ...snap.data() });
    });
    return unsub;
  }, [id]);

  useEffect(() => { messagesEnd.current?.scrollIntoView({ behavior:"smooth" }); }, [quote?.messages]);

  const sendMsg = async () => {
    if (!msg.trim()) return;
    const from = isWorker?"worker":"customer";
    const messages = [...(quote.messages||[]), { from, text:msg.trim(), time:now() }];
    await updateQuote(id, { messages });
    setMsg("");
  };

  const handleSendOffer = async () => {
    const amt = parseInt(offerAmt);
    if (!amt || amt < 1) return;
    await sendOffer(id, amt, quote.priceUnit||"per job", now());
    setOfferAmt(""); setShowOffer(false);
  };

  const handleAccept = async (amt) => { await acceptQuote(id, amt, now()); };
  const handleDecline = async ()    => { await declineQuote(id, now()); };

  const handlePay = () => {
    if (!quote.agreedPrice) return;
    const fee = Math.round(quote.agreedPrice * PLATFORM_FEE_PCT / 100);
    setPaying(true);
    openPaystack({
      email: quote.customerEmail||"customer@naijaskills.com",
      amountNaira: fee,
      metadata:{ type:"contact_fee", worker:quote.workerName, job:quote.jobTitle },
      onSuccess: async res => {
        await markQuotePaid(id, res.reference, quote.workerPhone, now());
        await logTransaction({ workerName:quote.workerName, customerEmail:quote.customerEmail, jobAmount:quote.agreedPrice, fee, type:"contact", ref:res.reference });
        setPaying(false);
      },
      onClose: () => setPaying(false),
    });
  };

  const sc = { pending:{bg:"rgba(245,158,11,.1)",c:"#92400E"}, countered:{bg:"rgba(37,99,235,.1)",c:G.blue}, accepted:{bg:"rgba(0,135,81,.1)",c:G.green}, declined:{bg:"rgba(220,38,38,.1)",c:G.red}, paid:{bg:"rgba(0,135,81,.15)",c:G.greenDark} };
  const status = sc[quote?.status]||sc.pending;

  if (!quote) return <div style={{textAlign:"center",padding:"80px",color:G.gray}}>Loading thread…</div>;

  const fee = Math.round((quote.agreedPrice||0)*PLATFORM_FEE_PCT/100);
  const lastQuoteMsg = [...(quote.messages||[])].reverse().find(m=>m.isQuote);

  return (
    <div style={{maxWidth:600,margin:"0 auto",display:"flex",flexDirection:"column",height:"calc(100vh - 70px)"}}>
      {/* Header */}
      <div style={{padding:"14px 18px 10px",borderBottom:"1px solid #E5E7EB",background:"#fff",flexShrink:0}}>
        <button onClick={()=>nav("/quotes")} style={{background:"none",border:"none",color:G.gray,cursor:"pointer",marginBottom:6,fontSize:".82rem"}}>← Back to quotes</button>
        <div style={{fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:".95rem",paddingRight:40,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{quote.jobTitle}</div>
        <div style={{display:"flex",alignItems:"center",gap:8,marginTop:4,flexWrap:"wrap"}}>
          <span style={{fontSize:".75rem",color:G.gray}}>{isWorker?quote.customerName:quote.workerName}</span>
          <span style={{background:status.bg,color:status.c,padding:"2px 9px",borderRadius:50,fontSize:".68rem",fontWeight:700,fontFamily:"Syne,sans-serif"}}>{quote.status}</span>
          {quote.agreedPrice>0&&<span style={{fontSize:".72rem",color:G.green,fontWeight:700}}>₦{fmt(quote.agreedPrice)} agreed</span>}
        </div>
        {quote.jobDate&&<div style={{fontSize:".72rem",color:G.gray,marginTop:2}}>📅 {quote.jobDate} {quote.jobLocation&&`· 📍 ${quote.jobLocation}`}</div>}
      </div>

      {/* Messages */}
      <div style={{flex:1,overflowY:"auto",padding:"14px 16px",display:"flex",flexDirection:"column",gap:10,background:G.cream}}>
        {(quote.messages||[]).map((m,i) => {
          const isMe = (isWorker&&m.from==="worker")||(!isWorker&&m.from==="customer");
          if (m.isSystem||m.from==="system") return (
            <div key={i} className="msg-in" style={{textAlign:"center",fontSize:".75rem",color:G.gray,background:"#fff",borderRadius:8,padding:"6px 12px",margin:"4px 20px"}}>{m.text}</div>
          );
          return (
            <div key={i} className="msg-in" style={{display:"flex",flexDirection:"column",alignItems:isMe?"flex-end":"flex-start"}}>
              {!isMe&&<div style={{fontSize:".65rem",color:G.gray,marginBottom:2,marginLeft:4}}>{m.from==="worker"?quote.workerName:quote.customerName}</div>}
              <div style={{maxWidth:"78%",background:m.isQuote?(isMe?"linear-gradient(135deg,#008751,#00b86a)":"linear-gradient(135deg,#1E40AF,#2563EB)"):(isMe?"#111827":"#fff"),color:m.isQuote?"#fff":(isMe?"#fff":G.dark),borderRadius:isMe?"16px 16px 4px 16px":"16px 16px 16px 4px",padding:"10px 14px",fontSize:".84rem",lineHeight:1.5,boxShadow:"0 2px 8px rgba(0,0,0,.08)"}}>
                {m.isQuote&&<div style={{fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"1rem",marginBottom:4}}>💰 ₦{fmt(m.amount)} {quote.priceUnit||"per job"}</div>}
                {m.text}
                {m.isQuote&&!isMe&&!["accepted","paid","declined"].includes(quote.status)&&(
                  <div style={{display:"flex",gap:6,marginTop:10}}>
                    <button onClick={()=>handleAccept(m.amount)} style={{flex:1,background:"rgba(255,255,255,.2)",border:"1.5px solid rgba(255,255,255,.5)",color:"#fff",borderRadius:8,padding:"6px",fontSize:".75rem",fontFamily:"Syne,sans-serif",fontWeight:700,cursor:"pointer"}}>✅ Accept</button>
                    <button onClick={handleDecline} style={{flex:1,background:"rgba(255,255,255,.1)",border:"1.5px solid rgba(255,255,255,.3)",color:"rgba(255,255,255,.8)",borderRadius:8,padding:"6px",fontSize:".75rem",cursor:"pointer"}}>❌ Decline</button>
                    <button onClick={()=>setShowOffer(true)} style={{flex:1,background:"rgba(255,255,255,.1)",border:"1.5px solid rgba(255,255,255,.3)",color:"rgba(255,255,255,.8)",borderRadius:8,padding:"6px",fontSize:".75rem",cursor:"pointer"}}>🔄 Counter</button>
                  </div>
                )}
              </div>
              <div style={{fontSize:".62rem",color:G.gray,marginTop:2,marginLeft:4,marginRight:4}}>{m.time}</div>
            </div>
          );
        })}
        <div ref={messagesEnd}/>
      </div>

      {/* Accept bar */}
      {quote.status==="accepted"&&!isWorker&&(
        <div style={{padding:"12px 16px",background:"linear-gradient(135deg,#F0FDF4,#DCFCE7)",borderTop:"1px solid rgba(0,135,81,.2)",flexShrink:0}}>
          <div style={{fontSize:".82rem",color:G.greenDark,fontWeight:600,marginBottom:6}}>✅ Agreed at ₦{fmt(quote.agreedPrice)}. Pay ₦{fmt(fee)} (10%) to unlock contact.</div>
          <button onClick={handlePay} disabled={paying} className="btn-primary" style={{width:"100%",opacity:paying?.6:1}}>{paying?"Opening Paystack…":`💳 Pay ₦${fmt(fee)} & Get Contact`}</button>
        </div>
      )}

      {/* Paid bar */}
      {quote.status==="paid"&&(
        <div style={{padding:"12px 16px",background:"linear-gradient(135deg,#F0FDF4,#DCFCE7)",borderTop:"1px solid rgba(0,135,81,.2)",flexShrink:0,textAlign:"center"}}>
          <div style={{fontFamily:"Syne,sans-serif",fontWeight:800,color:G.greenDark,marginBottom:8}}>💳 Paid · Contact Unlocked</div>
          <div style={{fontFamily:"Syne,sans-serif",fontSize:"1.1rem",fontWeight:800,marginBottom:10}}>{quote.workerPhone}</div>
          <div style={{display:"flex",gap:8}}>
            <a href={`tel:+234${quote.workerPhone?.substring(1)}`} style={{flex:1,padding:10,borderRadius:10,background:G.green,color:"#fff",fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:".82rem",textDecoration:"none",textAlign:"center"}}>📞 Call</a>
            <a href={`https://wa.me/234${quote.workerPhone?.substring(1)}`} target="_blank" rel="noreferrer" style={{flex:1,padding:10,borderRadius:10,background:"#25D366",color:"#fff",fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:".82rem",textDecoration:"none",textAlign:"center"}}>💬 WhatsApp</a>
          </div>
        </div>
      )}

      {/* Input */}
      {!["paid","declined"].includes(quote.status)&&(
        <div style={{padding:"10px 14px",borderTop:"1px solid #E5E7EB",background:"#fff",flexShrink:0}}>
          {showOffer&&(
            <div style={{background:G.light,borderRadius:10,padding:"10px 12px",marginBottom:8,display:"flex",gap:8,alignItems:"center"}}>
              <span style={{fontSize:".82rem",fontWeight:600,whiteSpace:"nowrap"}}>₦ Offer:</span>
              <input type="number" value={offerAmt} onChange={e=>setOfferAmt(e.target.value)} placeholder="Amount" className="form-input" style={{flex:1,padding:"7px 10px"}}/>
              <button onClick={handleSendOffer} className="btn-primary" style={{padding:"7px 14px",fontSize:".8rem"}}>Send</button>
              <button onClick={()=>setShowOffer(false)} style={{background:G.light,border:"none",borderRadius:8,padding:"7px 10px",cursor:"pointer"}}>✕</button>
            </div>
          )}
          <div style={{display:"flex",gap:8,alignItems:"flex-end"}}>
            <textarea value={msg} onChange={e=>setMsg(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendMsg();}}} placeholder="Type a message…" style={{flex:1,border:"1.5px solid #E5E7EB",borderRadius:12,padding:"10px 12px",fontSize:".85rem",resize:"none",height:44,outline:"none",lineHeight:1.4}}/>
            {isWorker&&!showOffer&&quote.status!=="accepted"&&<button onClick={()=>setShowOffer(true)} style={{background:"rgba(0,135,81,.1)",color:G.green,border:"1.5px solid rgba(0,135,81,.2)",borderRadius:10,padding:"0 10px",fontSize:".75rem",fontFamily:"Syne,sans-serif",fontWeight:700,whiteSpace:"nowrap",height:44,cursor:"pointer"}}>💰 Quote</button>}
            {!isWorker&&!showOffer&&quote.status==="countered"&&<button onClick={()=>setShowOffer(true)} style={{background:"rgba(37,99,235,.1)",color:G.blue,border:"1.5px solid rgba(37,99,235,.2)",borderRadius:10,padding:"0 10px",fontSize:".75rem",fontFamily:"Syne,sans-serif",fontWeight:700,whiteSpace:"nowrap",height:44,cursor:"pointer"}}>🔄 Counter</button>}
            <button onClick={sendMsg} style={{background:G.green,color:"#fff",border:"none",borderRadius:10,padding:"0 14px",fontSize:"1rem",height:44,cursor:"pointer"}}>➤</button>
          </div>
        </div>
      )}
    </div>
  );
}
