import React, { useState, useEffect } from "react";
import { G, fmt, AVATAR_BG, fmtPrice, ADMIN_PASSWORD } from "../utils/constants";
import { getAllWorkers, updateWorkerStatus, deleteWorker, addTrustedWorker, getAllTransactions } from "../services/dataService";
import TagInput from "../components/TagInput";
import { CATEGORIES, STATES } from "../utils/constants";

export default function AdminPage() {
  const [authed, setAuthed] = useState(false);
  const [pwd, setPwd]       = useState("");
  const [pwdErr, setPwdErr] = useState("");
  const [tab, setTab]       = useState("pending");
  const [workers, setWorkers] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [search, setSearch] = useState("");
  const [showTrustedForm, setShowTrustedForm] = useState(false);
  const [loading, setLoading] = useState(false);

  const login = () => { if(pwd===ADMIN_PASSWORD){setAuthed(true);}else setPwdErr("Incorrect password."); };

  useEffect(() => {
    if (!authed) return;
    setLoading(true);
    Promise.all([getAllWorkers(), getAllTransactions()])
      .then(([ws,ts]) => {
        setWorkers(ws.docs.map(d=>({id:d.id,...d.data()})));
        setTransactions(ts.docs.map(d=>({id:d.id,...d.data()})));
      }).finally(()=>setLoading(false));
  }, [authed]);

  const approve = async (w) => { await updateWorkerStatus(w.id,"approved",true); setWorkers(prev=>prev.map(x=>x.id===w.id?{...x,status:"approved",verified:true}:x)); };
  const suspend = async (w) => { await updateWorkerStatus(w.id,"pending",false); setWorkers(prev=>prev.map(x=>x.id===w.id?{...x,status:"pending",verified:false}:x)); };
  const remove  = async (w) => { if(w.trusted){alert("Trusted workers are protected.");return;} if(!window.confirm(`Delete ${w.name}?`))return; await deleteWorker(w.id); setWorkers(prev=>prev.filter(x=>x.id!==w.id)); };
  const addTrusted = async (data) => { const ref = await addTrustedWorker(data); setWorkers(prev=>[{id:ref.id,...data,trusted:true,status:"approved",verified:true},...prev]); setShowTrustedForm(false); setTab("trusted"); };

  const totalRev = transactions.reduce((s,t)=>s+(t.fee||0),0);
  const regRev   = transactions.filter(t=>t.type==="registration").reduce((s,t)=>s+(t.fee||0),0);
  const conRev   = transactions.filter(t=>t.type==="contact").reduce((s,t)=>s+(t.fee||0),0);
  const pending  = workers.filter(w=>w.status==="pending").length;
  const trusted  = workers.filter(w=>w.trusted).length;

  const displayed = workers.filter(w => {
    if(tab==="pending")  return w.status==="pending";
    if(tab==="approved") return w.status==="approved"&&!w.trusted;
    if(tab==="trusted")  return w.trusted;
    return true;
  }).filter(w=>!search||w.name?.toLowerCase().includes(search.toLowerCase())||w.skill?.toLowerCase().includes(search.toLowerCase()));

  const tabS = v => ({ padding:"8px 13px",borderRadius:50,fontSize:".76rem",fontWeight:600,border:`1.5px solid ${tab===v?(v==="trusted"?"#DAA520":G.green):"#E5E7EB"}`,background:tab===v?(v==="trusted"?"linear-gradient(135deg,#DAA520,#FFD700)":G.green):"#fff",color:tab===v?(v==="trusted"?"#3D2800":"#fff"):G.gray,cursor:"pointer",fontFamily:"Syne,sans-serif" });

  if (!authed) return (
    <div style={{display:"flex",alignItems:"center",justifyContent:"center",minHeight:"70vh",padding:24}}>
      <div className="pop-in" style={{background:"#fff",borderRadius:20,padding:"36px 28px",width:"100%",maxWidth:360,boxShadow:"0 8px 40px rgba(0,0,0,.12)",textAlign:"center"}}>
        <div style={{fontSize:"3rem",marginBottom:12}}>🛡️</div>
        <div style={{fontFamily:"Syne,sans-serif",fontSize:"1.3rem",fontWeight:800,marginBottom:6}}>Admin Login</div>
        <input type="password" value={pwd} onChange={e=>setPwd(e.target.value)} onKeyDown={e=>e.key==="Enter"&&login()} placeholder="Password" className={`form-input${pwdErr?" error":""}`} style={{marginBottom:8}}/>
        {pwdErr&&<div style={{color:G.red,fontSize:".78rem",marginBottom:10}}>{pwdErr}</div>}
        <button onClick={login} className="btn-primary" style={{width:"100%"}}>Login</button>
        <div style={{fontSize:".72rem",color:G.gray,marginTop:12}}>Demo: <code style={{background:G.light,padding:"2px 6px",borderRadius:4}}>admin123</code></div>
      </div>
    </div>
  );

  return (
    <div className="page-pad">
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:4,flexWrap:"wrap",gap:10}}>
        <div style={{fontFamily:"Syne,sans-serif",fontSize:"1.3rem",fontWeight:800}}>🛡️ Admin Panel</div>
        <button onClick={()=>setShowTrustedForm(!showTrustedForm)} className="btn-gold">{showTrustedForm?"✕ Close":"👑 Add Trusted Worker"}</button>
      </div>

      {showTrustedForm&&<div style={{marginBottom:20}}><TrustedForm onAdd={addTrusted} onCancel={()=>setShowTrustedForm(false)}/></div>}

      {/* Stats */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,marginBottom:20}}>
        {[[workers.length,"Workers","👷"],[pending,"Pending","⏳"],[trusted,"Trusted","👑"],[`₦${fmt(totalRev)}`, "Revenue","💰"]].map(([n,l,i])=>(
          <div key={l} style={{background:"#fff",borderRadius:14,padding:"12px 8px",textAlign:"center",boxShadow:"0 2px 12px rgba(0,0,0,.06)"}}>
            <div style={{fontSize:"1rem",marginBottom:3}}>{i}</div>
            <div style={{fontFamily:"Syne,sans-serif",fontSize:".9rem",fontWeight:800,color:l==="Trusted"?"#B8860B":G.green}}>{n}</div>
            <div style={{fontSize:".6rem",color:G.gray,textTransform:"uppercase",letterSpacing:".6px"}}>{l}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="nav-tabs" style={{marginBottom:16}}>
        <button style={tabS("pending")}     onClick={()=>setTab("pending")}>⏳ Pending ({pending})</button>
        <button style={tabS("approved")}    onClick={()=>setTab("approved")}>✅ Approved</button>
        <button style={tabS("trusted")}     onClick={()=>setTab("trusted")}>👑 Trusted ({trusted})</button>
        <button style={tabS("all")}         onClick={()=>setTab("all")}>👥 All</button>
        <button style={tabS("transactions")}onClick={()=>setTab("transactions")}>💳 Revenue</button>
      </div>

      {tab==="transactions" ? (
        <div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:16}}>
            <div style={{background:"linear-gradient(135deg,#1E40AF,#2563EB)",borderRadius:14,padding:14,textAlign:"center",color:"#fff"}}><div style={{fontSize:".75rem",opacity:.85}}>Registration Fees</div><div style={{fontFamily:"Syne,sans-serif",fontSize:"1.3rem",fontWeight:800}}>₦{fmt(regRev)}</div></div>
            <div style={{background:"linear-gradient(135deg,#008751,#00b86a)",borderRadius:14,padding:14,textAlign:"center",color:"#fff"}}><div style={{fontSize:".75rem",opacity:.85}}>Contact Fees</div><div style={{fontFamily:"Syne,sans-serif",fontSize:"1.3rem",fontWeight:800}}>₦{fmt(conRev)}</div></div>
          </div>
          {transactions.map(t=>(
            <div key={t.id} style={{background:"#fff",borderRadius:14,padding:"14px 16px",marginBottom:10,boxShadow:"0 2px 12px rgba(0,0,0,.06)",borderLeft:`4px solid ${t.type==="registration"?G.blue:G.green}`}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                <div style={{fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:".88rem"}}>{t.workerName}</div>
                <div style={{background:t.type==="registration"?"rgba(37,99,235,.1)":"rgba(0,135,81,.1)",color:t.type==="registration"?G.blue:G.green,padding:"2px 10px",borderRadius:50,fontSize:".68rem",fontWeight:700}}>{t.type==="registration"?"📋 Reg":"💼 Contact"}</div>
              </div>
              <div style={{fontSize:".78rem",color:G.gray}}>{t.customerEmail} · {t.timestamp?.toDate?.()?.toLocaleDateString()||""}</div>
              <div style={{display:"flex",gap:14,fontSize:".8rem",marginTop:4}}><span>Amount: <strong>₦{fmt(t.jobAmount)}</strong></span><span>Fee: <strong style={{color:t.type==="registration"?G.blue:G.green}}>₦{fmt(t.fee)}</strong></span></div>
            </div>
          ))}
          <div style={{background:"linear-gradient(135deg,#111827,#374151)",borderRadius:14,padding:"16px",color:"#fff",textAlign:"center",marginTop:12}}>
            <div style={{fontSize:".8rem",opacity:.8}}>Total Revenue</div>
            <div style={{fontFamily:"Syne,sans-serif",fontSize:"2rem",fontWeight:800}}>₦{fmt(totalRev)}</div>
          </div>
        </div>
      ) : (
        <div>
          {loading&&<div style={{textAlign:"center",padding:"40px",color:G.gray}}>Loading…</div>}
          <input className="form-input" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search workers…" style={{marginBottom:14}}/>
          {displayed.map(w=>(
            <div key={w.id} style={{background:"#fff",borderRadius:14,padding:"14px 16px",marginBottom:10,boxShadow:w.trusted?"0 2px 12px rgba(218,165,32,.2)":"0 2px 12px rgba(0,0,0,.06)",border:w.trusted?"2px solid #DAA520":"none",display:"flex",alignItems:"center",gap:12}}>
              <div style={{fontSize:"1.8rem",width:44,height:44,display:"flex",alignItems:"center",justifyContent:"center",borderRadius:12,background:w.trusted?"linear-gradient(135deg,#FFF8DC,#FFEAA0)":AVATAR_BG[w.category]||G.light,flexShrink:0}}>{w.avatar||"👷"}</div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
                  <div style={{fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:".88rem"}}>{w.name}</div>
                  {w.trusted&&<span className="badge-trusted">👑 Trusted</span>}
                </div>
                <div style={{fontSize:".75rem",color:G.green}}>{w.skill} · {w.city}, {w.state}</div>
                <div style={{fontSize:".7rem",color:G.gray,display:"flex",gap:10,marginTop:2,flexWrap:"wrap"}}>
                  <span>{fmtPrice(w)}</span>
                  {w.regPaid&&<span style={{color:G.blue}}>📋 Reg paid</span>}
                  {!w.regPaid&&<span style={{color:G.red}}>⚠️ Reg unpaid</span>}
                </div>
              </div>
              <div style={{display:"flex",flexDirection:"column",gap:5,flexShrink:0}}>
                <div style={{padding:"2px 9px",borderRadius:50,fontSize:".63rem",fontWeight:700,fontFamily:"Syne,sans-serif",background:w.trusted?"rgba(218,165,32,.2)":w.status==="approved"?"rgba(0,135,81,.1)":"rgba(245,166,35,.15)",color:w.trusted?"#B8860B":w.status==="approved"?G.green:"#7C5A00",textAlign:"center"}}>{w.trusted?"👑 Trusted":w.status==="approved"?"✅ Live":"⏳ Pending"}</div>
                {w.status==="pending"&&!w.trusted&&<button onClick={()=>approve(w)} style={{background:G.green,color:"#fff",border:"none",borderRadius:8,padding:"5px 10px",fontSize:".7rem",fontFamily:"Syne,sans-serif",fontWeight:700,cursor:"pointer"}}>Approve</button>}
                {w.status==="approved"&&!w.trusted&&<button onClick={()=>suspend(w)} style={{background:G.light,color:G.gray,border:"none",borderRadius:8,padding:"5px 10px",fontSize:".7rem",cursor:"pointer"}}>Suspend</button>}
                {!w.trusted&&<button onClick={()=>remove(w)} style={{background:"rgba(220,38,38,.08)",color:G.red,border:"none",borderRadius:8,padding:"5px 10px",fontSize:".7rem",cursor:"pointer"}}>Delete</button>}
                {w.trusted&&<div style={{fontSize:".6rem",color:"#B8860B",textAlign:"center"}}>🔒 Protected</div>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function TrustedForm({ onAdd, onCancel }) {
  const e={name:"",phone:"",skill:"",cat:"",city:"",state:"",priceType:"fixed",priceUnit:"per job",rate:"",rateMin:"",rateMax:"",bio:"",avatar:""};
  const [f,setF]=useState(e); const [tags,setTags]=useState([]); const [errs,setErrs]=useState({});
  const set=k=>ev=>setF(p=>({...p,[k]:ev.target.value}));
  const submit=()=>{
    const err={};
    ["name","phone","skill","cat","city","state","bio"].forEach(k=>{if(!f[k].trim())err[k]="Required";});
    if(tags.length===0)err.tags="Add at least one tag";
    if(Object.keys(err).length){setErrs(err);return;}
    const catAv={"Home Services":"🛠️","Construction & Trades":"🏗️","Tech & IT":"💻","Creative & Design":"🎨"};
    onAdd({name:f.name.trim(),phone:f.phone.trim(),skill:f.skill.trim(),category:f.cat,city:f.city.trim(),state:f.state,avatar:f.avatar.trim()||catAv[f.cat]||"👷",bio:f.bio.trim(),tags,rate:parseInt(f.priceType==="range"?f.rateMin:f.rate)||0,rateMin:parseInt(f.rateMin)||null,rateMax:parseInt(f.rateMax)||null,priceType:f.priceType,priceUnit:f.priceUnit});
  };
  const inp=k=>({className:`form-input${errs[k]?" error":""}`,value:f[k],onChange:set(k)});
  const lbl=(t,r)=><label style={{display:"block",fontSize:".78rem",fontWeight:600,marginBottom:4}}>{t}{r&&<span style={{color:G.red}}> *</span>}</label>;
  const err=k=>errs[k]&&<div style={{fontSize:".7rem",color:G.red,marginTop:3}}>{errs[k]}</div>;
  return (
    <div style={{background:"linear-gradient(135deg,#FFFDF0,#FFF5CC)",border:"2px solid #DAA520",borderRadius:16,padding:20}}>
      <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:16}}><span style={{fontSize:"1.8rem"}}>👑</span><div><div style={{fontFamily:"Syne,sans-serif",fontWeight:800,color:"#B8860B"}}>Add Trusted Worker</div><div style={{fontSize:".75rem",color:"#7C5A00"}}>Instantly approved · No reg fee</div></div></div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:10}}><div>{lbl("Full Name",true)}<input {...inp("name")} placeholder="e.g. Chidi Okeke"/>{err("name")}</div><div>{lbl("Phone",true)}<input {...inp("phone")} placeholder="08012345678" type="tel"/>{err("phone")}</div></div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:10}}><div>{lbl("Skill",true)}<input {...inp("skill")} placeholder="e.g. Plumber"/>{err("skill")}</div><div>{lbl("Category",true)}<select {...inp("cat")}><option value="">--</option>{CATEGORIES.map(c=><option key={c} value={c}>{c}</option>)}</select>{err("cat")}</div></div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:10}}><div>{lbl("City",true)}<input {...inp("city")} placeholder="e.g. Lagos"/>{err("city")}</div><div>{lbl("State",true)}<select {...inp("state")}><option value="">--</option>{STATES.map(s=><option key={s}>{s}</option>)}</select>{err("state")}</div></div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:10}}><div>{lbl("Rate (₦)",true)}<input {...inp("rate")} type="number" min="0" placeholder="5000"/>{err("rate")}</div><div>{lbl("Emoji Avatar")}<input {...inp("avatar")} placeholder="e.g. 🔧"/></div></div>
      <div style={{marginBottom:10}}>{lbl("Tags",true)}<TagInput tags={tags} setTags={setTags} category={f.cat} error={errs.tags}/></div>
      <div style={{marginBottom:16}}>{lbl("Bio",true)}<textarea {...inp("bio")} placeholder="Why do you trust this worker?" style={{resize:"vertical",minHeight:70}}/>{err("bio")}</div>
      <div style={{display:"flex",gap:8}}><button onClick={submit} className="btn-gold" style={{flex:1}}>👑 Add as Trusted Worker</button>{onCancel&&<button onClick={onCancel} style={{background:G.light,color:G.gray,border:"none",borderRadius:12,padding:"12px 16px",cursor:"pointer"}}>Cancel</button>}</div>
    </div>
  );
}
