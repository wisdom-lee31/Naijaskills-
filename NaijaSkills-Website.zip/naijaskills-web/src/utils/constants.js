export const PAYSTACK_PUBLIC_KEY = "pk_test_YOUR_PUBLIC_KEY_HERE";
export const PLATFORM_FEE_PCT   = 10;
export const REG_FEE            = 1000;
export const BANK_NAME          = "First Bank Nigeria";
export const BANK_ACCOUNT_NUM   = "1234567890";
export const BANK_ACCOUNT_NAME  = "NaijaSkills Ltd";
export const ADMIN_PASSWORD     = "admin123";

export const CATEGORIES = [
  "Home Services", "Construction & Trades", "Tech & IT", "Creative & Design",
];

export const PRICE_UNITS = [
  "per job","per hour","per day","per week","per month","negotiable",
];

export const STATES = [
  "Abia","Adamawa","Akwa Ibom","Anambra","Bauchi","Bayelsa","Benue","Borno",
  "Cross River","Delta","Ebonyi","Edo","Ekiti","Enugu","FCT","Gombe","Imo",
  "Jigawa","Kaduna","Kano","Katsina","Kebbi","Kogi","Kwara","Lagos","Nasarawa",
  "Niger","Ogun","Ondo","Osun","Oyo","Plateau","Rivers","Sokoto","Taraba",
  "Yobe","Zamfara",
];

export const SUGGESTED_TAGS = {
  "Home Services":["Deep Cleaning","House Cleaning","Laundry","Ironing","Plumbing","Pipe Repair","Drainage","Electrician","Wiring","Solar","Pest Control","Nanny","Elderly Care","Cooking","Gardening","AC Repair","Generator Repair","Pool Cleaning","Painting","Interior Decor"],
  "Construction & Trades":["Bricklaying","Masonry","Plastering","Tiling","Roofing","Waterproofing","Carpentry","Furniture","Welding","Fabrication","Gates","Railings","Steel Work","Epoxy Floors","POP Design","Aluminium Work","Glass Fitting","Screeding","Landscaping"],
  "Tech & IT":["Web Development","React","WordPress","E-Commerce","Mobile App","Android","iOS","Graphic Design","Logo Design","Branding","Social Media","Content Creation","Video Editing","CCTV","Networking","PC Repair","Data Recovery","SEO","Digital Marketing","UI/UX Design"],
  "Creative & Design":["Fashion Design","Tailoring","Ankara","Aso-ebi","Embroidery","Makeup Artist","Bridal Makeup","Photography","Videography","Drone","Weddings","DJ","Catering","Cake Design","Event Planning","Decoration","Floral Design","Printing","Signage","Animation"],
};

export const TAG_COLORS = [
  {bg:"rgba(0,135,81,.12)",   color:"#005c38", border:"rgba(0,135,81,.3)"},
  {bg:"rgba(37,99,235,.1)",   color:"#1E40AF", border:"rgba(37,99,235,.25)"},
  {bg:"rgba(124,58,237,.1)",  color:"#5B21B6", border:"rgba(124,58,237,.25)"},
  {bg:"rgba(245,158,11,.12)", color:"#92400E", border:"rgba(245,158,11,.3)"},
  {bg:"rgba(236,72,153,.1)",  color:"#9D174D", border:"rgba(236,72,153,.25)"},
  {bg:"rgba(20,184,166,.12)", color:"#0F766E", border:"rgba(20,184,166,.3)"},
];
export const tagColor = (i) => TAG_COLORS[i % TAG_COLORS.length];

export const AVATAR_BG = {
  "Home Services":         "linear-gradient(135deg,#E8F5E9,#C8E6C9)",
  "Construction & Trades": "linear-gradient(135deg,#FFF8E1,#FFE082)",
  "Tech & IT":             "linear-gradient(135deg,#E3F2FD,#BBDEFB)",
  "Creative & Design":     "linear-gradient(135deg,#FCE4EC,#F8BBD0)",
};

export const QUOTE_STATUS_LABELS = {
  pending:"⏳ Pending", countered:"🔄 Negotiating",
  accepted:"✅ Accepted", declined:"❌ Declined", paid:"💳 Paid",
};

export const G = {
  green:"#008751", greenDark:"#005c38", greenLight:"#00b86a",
  gold:"#F5A623",  goldLight:"#FFD080", trustedGold:"#B8860B",
  cream:"#FDF6EC", white:"#ffffff", gray:"#6B7280",
  light:"#F3F4F6", dark:"#111827",  red:"#DC2626", blue:"#2563EB",
};

export const fmt   = (n)  => Number(n || 0).toLocaleString();
export const stars = (r)  => "★".repeat(Math.floor(r)) + (r % 1 >= 0.5 ? "½" : "");
export const now   = ()   => new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"});
export const addYear = () => { const d = new Date(); d.setFullYear(d.getFullYear()+1); return d.toISOString().split("T")[0]; };

export const fmtPrice = (w) => {
  if (!w) return "";
  if (w.priceType === "negotiable") return "Negotiable";
  if (w.priceType === "range" && w.rateMin && w.rateMax)
    return `₦${fmt(w.rateMin)} – ₦${fmt(w.rateMax)} ${w.priceUnit || "per job"}`;
  return `₦${fmt(w.rate)} ${w.priceUnit || "per job"}`;
};

export const openPaystack = ({ email, amountNaira, metadata, onSuccess, onClose }) => {
  if (typeof window.PaystackPop === "undefined") {
    alert("Paystack script not loaded. Add it to public/index.html");
    return;
  }
  const handler = window.PaystackPop.setup({
    key: PAYSTACK_PUBLIC_KEY, email, amount: amountNaira * 100,
    currency: "NGN", ref: "NS_" + Date.now(), metadata,
    callback: (res) => onSuccess(res),
    onClose,
  });
  handler.openIframe();
};
